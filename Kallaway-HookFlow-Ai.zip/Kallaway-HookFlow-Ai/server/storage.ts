import { savedHooks, trainingItems, frameworks, type SavedHook, type InsertSavedHook, type TrainingItem, type InsertTrainingItem, type Framework, type InsertFramework } from "@shared/schema";
import { db } from "./db";
import { eq, and, sql } from "drizzle-orm";

const TEMPLATE_USER_ID = "116566430930709465233";

export interface IStorage {
  getHooksByUser(userId: string): Promise<SavedHook[]>;
  createHook(hook: InsertSavedHook): Promise<SavedHook>;
  deleteHook(id: string, userId: string): Promise<void>;
  
  getFrameworksByUser(userId: string): Promise<Framework[]>;
  createFramework(framework: InsertFramework): Promise<Framework>;
  updateFramework(id: string, userId: string, data: Partial<InsertFramework>): Promise<Framework>;
  deleteFramework(id: string, userId: string): Promise<void>;
  
  getTrainingByUser(userId: string): Promise<TrainingItem[]>;
  getTrainingByFramework(frameworkId: string, userId: string): Promise<TrainingItem[]>;
  createTraining(item: InsertTrainingItem): Promise<TrainingItem>;
  deleteTraining(id: string, userId: string): Promise<void>;
  
  seedNewUserFromTemplate(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getHooksByUser(userId: string): Promise<SavedHook[]> {
    return await db.select().from(savedHooks).where(eq(savedHooks.userId, userId));
  }

  async createHook(hook: InsertSavedHook): Promise<SavedHook> {
    const [created] = await db.insert(savedHooks).values(hook).returning();
    return created;
  }

  async deleteHook(id: string, userId: string): Promise<void> {
    await db.delete(savedHooks).where(eq(savedHooks.id, id));
  }

  async getFrameworksByUser(userId: string): Promise<Framework[]> {
    return await db.select().from(frameworks).where(eq(frameworks.userId, userId));
  }

  async createFramework(framework: InsertFramework): Promise<Framework> {
    const [created] = await db.insert(frameworks).values(framework).returning();
    return created;
  }

  async updateFramework(id: string, userId: string, data: Partial<InsertFramework>): Promise<Framework> {
    const [updated] = await db.update(frameworks)
      .set(data)
      .where(and(eq(frameworks.id, id), eq(frameworks.userId, userId)))
      .returning();
    return updated;
  }

  async deleteFramework(id: string, userId: string): Promise<void> {
    await db.delete(trainingItems).where(eq(trainingItems.frameworkId, id));
    await db.delete(frameworks).where(and(eq(frameworks.id, id), eq(frameworks.userId, userId)));
  }

  async getTrainingByUser(userId: string): Promise<TrainingItem[]> {
    return await db.select().from(trainingItems).where(eq(trainingItems.userId, userId));
  }

  async getTrainingByFramework(frameworkId: string, userId: string): Promise<TrainingItem[]> {
    return await db.select().from(trainingItems).where(
      and(eq(trainingItems.frameworkId, frameworkId), eq(trainingItems.userId, userId))
    );
  }

  async createTraining(item: InsertTrainingItem): Promise<TrainingItem> {
    const [created] = await db.insert(trainingItems).values(item).returning();
    return created;
  }

  async deleteTraining(id: string, userId: string): Promise<void> {
    await db.delete(trainingItems).where(
      and(eq(trainingItems.id, id), eq(trainingItems.userId, userId))
    );
  }

  async seedNewUserFromTemplate(userId: string): Promise<void> {
    if (userId === TEMPLATE_USER_ID) {
      return;
    }

    const existingFrameworks = await this.getFrameworksByUser(userId);
    if (existingFrameworks.length > 0) {
      return;
    }

    const templateFrameworks = await this.getFrameworksByUser(TEMPLATE_USER_ID);
    const templateTraining = await this.getTrainingByUser(TEMPLATE_USER_ID);

    if (templateFrameworks.length === 0) {
      return;
    }

    const frameworkIdMap: Record<string, string> = {};

    for (const framework of templateFrameworks) {
      const [newFramework] = await db.insert(frameworks).values({
        userId,
        name: framework.name,
        description: framework.description,
      }).returning();
      frameworkIdMap[framework.id] = newFramework.id;
    }

    for (const item of templateTraining) {
      const newFrameworkId = item.frameworkId ? frameworkIdMap[item.frameworkId] : null;
      await db.insert(trainingItems).values({
        userId,
        frameworkId: newFrameworkId,
        title: item.title,
        content: item.content,
      });
    }

    console.log(`Seeded user ${userId} with ${templateFrameworks.length} frameworks and ${templateTraining.length} training items`);
  }
}

export const storage = new DatabaseStorage();
