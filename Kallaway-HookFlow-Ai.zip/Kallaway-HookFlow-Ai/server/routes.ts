import type { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";

function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  const devBypass = process.env.DEV_AUTH_BYPASS === "true";
  
  if (devBypass) {
    (req as any).user = { id: "dev-user" };
    return next();
  }
  
  if (req.isAuthenticated && req.isAuthenticated() && req.user) {
    return next();
  }
  
  res.status(401).json({ error: "Not authenticated" });
}

export function registerRoutes(app: Express): void {
  // Framework routes
  app.get("/api/frameworks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const items = await storage.getFrameworksByUser(userId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching frameworks:", error);
      res.status(500).json({ message: "Failed to fetch frameworks" });
    }
  });

  app.post("/api/frameworks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const framework = await storage.createFramework({ ...req.body, userId });
      res.json(framework);
    } catch (error) {
      console.error("Error creating framework:", error);
      res.status(500).json({ message: "Failed to create framework" });
    }
  });

  app.put("/api/frameworks/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const framework = await storage.updateFramework(req.params.id, userId, req.body);
      res.json(framework);
    } catch (error) {
      console.error("Error updating framework:", error);
      res.status(500).json({ message: "Failed to update framework" });
    }
  });

  app.delete("/api/frameworks/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      await storage.deleteFramework(req.params.id, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting framework:", error);
      res.status(500).json({ message: "Failed to delete framework" });
    }
  });

  // Training routes
  app.get("/api/training", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const items = await storage.getTrainingByUser(userId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching training:", error);
      res.status(500).json({ message: "Failed to fetch training" });
    }
  });

  app.get("/api/training/framework/:frameworkId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const items = await storage.getTrainingByFramework(req.params.frameworkId, userId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching training by framework:", error);
      res.status(500).json({ message: "Failed to fetch training" });
    }
  });

  app.post("/api/training", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const item = await storage.createTraining({ ...req.body, userId });
      res.json(item);
    } catch (error) {
      console.error("Error creating training:", error);
      res.status(500).json({ message: "Failed to create training" });
    }
  });

  app.delete("/api/training/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      await storage.deleteTraining(req.params.id, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting training:", error);
      res.status(500).json({ message: "Failed to delete training" });
    }
  });

  // Hook routes
  app.get("/api/hooks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const hooks = await storage.getHooksByUser(userId);
      res.json(hooks);
    } catch (error) {
      console.error("Error fetching hooks:", error);
      res.status(500).json({ message: "Failed to fetch hooks" });
    }
  });

  app.post("/api/hooks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const hook = await storage.createHook({ ...req.body, userId });
      res.json(hook);
    } catch (error) {
      console.error("Error creating hook:", error);
      res.status(500).json({ message: "Failed to create hook" });
    }
  });

  app.delete("/api/hooks/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      await storage.deleteHook(req.params.id, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting hook:", error);
      res.status(500).json({ message: "Failed to delete hook" });
    }
  });
}
