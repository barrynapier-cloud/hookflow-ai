import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { Express } from "express";
import { db, pool } from "./db";
import { users, sessions } from "../shared/schema";
import { eq } from "drizzle-orm";

const PgSession = connectPgSimple(session);

export async function setupGoogleAuth(app: Express) {
  const sessionSecret = process.env.SESSION_SECRET || "hookflow-secret-key-change-in-production";
  
  const isDeployment = process.env.REPLIT_DEPLOYMENT === "1";
  const isReplitDev = !!process.env.REPLIT_DEV_DOMAIN;
  const isSecure = isDeployment || isReplitDev;
  
  console.log("Auth config:", { isDeployment, isReplitDev, isSecure });
  
  app.set("trust proxy", 1);
  
  app.use(
    session({
      store: new PgSession({
        pool,
        tableName: "sessions",
        createTableIfMissing: false,
      }),
      secret: sessionSecret,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: isSecure,
        httpOnly: true,
        maxAge: 30 * 24 * 60 * 60 * 1000,
        sameSite: "lax",
      },
    })
  );

  app.use(passport.initialize());
  app.use(passport.session());

  let callbackURL: string;
  
  if (isDeployment) {
    const domains = process.env.REPLIT_DOMAINS?.split(",") || [];
    const productionDomain = domains.find(d => d.includes(".replit.app")) || domains[0];
    callbackURL = `https://${productionDomain}/api/auth/google/callback`;
  } else if (process.env.REPLIT_DEV_DOMAIN) {
    callbackURL = `https://${process.env.REPLIT_DEV_DOMAIN}/api/auth/google/callback`;
  } else {
    callbackURL = "http://localhost:3001/api/auth/google/callback";
  }
  
  console.log("OAuth callback URL:", callbackURL);

  passport.use(
    new GoogleStrategy(
      {
        clientID: process.env.GOOGLE_CLIENT_ID!,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
        callbackURL,
        scope: ["openid", "profile", "email"],
      },
      async (accessToken, refreshToken, profile, done) => {
        try {
          const googleId = profile.id;
          const email = profile.emails?.[0]?.value || "";
          const firstName = profile.name?.givenName || "";
          const lastName = profile.name?.familyName || "";
          const profileImageUrl = profile.photos?.[0]?.value || null;

          let user = await db.query.users.findFirst({
            where: eq(users.id, googleId),
          });

          if (!user) {
            const [newUser] = await db
              .insert(users)
              .values({
                id: googleId,
                email,
                firstName,
                lastName,
                profileImageUrl,
              })
              .returning();
            user = newUser;
          } else {
            await db
              .update(users)
              .set({ email, firstName, lastName, profileImageUrl })
              .where(eq(users.id, googleId));
          }

          return done(null, user);
        } catch (error) {
          return done(error as Error);
        }
      }
    )
  );

  passport.serializeUser((user: any, done) => {
    console.log("Serializing user:", user.id);
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    console.log("Deserializing user:", id);
    try {
      const user = await db.query.users.findFirst({
        where: eq(users.id, id),
      });
      console.log("Deserialized user found:", !!user);
      done(null, user || null);
    } catch (error) {
      console.error("Deserialize error:", error);
      done(error);
    }
  });
}

export function registerGoogleAuthRoutes(app: Express) {
  app.get(
    "/api/auth/google",
    passport.authenticate("google", { scope: ["openid", "profile", "email"] })
  );

  app.get(
    "/api/auth/google/callback",
    passport.authenticate("google", { failureRedirect: "/" }),
    (req, res) => {
      console.log("OAuth callback - user:", req.user ? (req.user as any).id : "none");
      console.log("OAuth callback - session ID:", req.sessionID);
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
        }
        console.log("Session saved, redirecting to /");
        res.redirect("/");
      });
    }
  );

  app.get("/api/auth/user", (req, res) => {
    // Dev bypass - skip auth in development iframe
    const devBypass = process.env.DEV_AUTH_BYPASS === "true";
    if (devBypass) {
      return res.json({
        id: "dev-user",
        email: "dev@hookflow.ai",
        firstName: "Dev",
        lastName: "User",
        profileImageUrl: null,
      });
    }
    
    if (req.isAuthenticated() && req.user) {
      const user = req.user as any;
      res.json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        profileImageUrl: user.profileImageUrl,
      });
    } else {
      res.status(401).json({ error: "Not authenticated" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      req.session.destroy((err) => {
        res.json({ success: true });
      });
    });
  });
}
