# HookFlow AI

## Overview
HookFlow AI is a viral content strategy tool that helps creators analyze successful video hooks and generate compelling scripts. It uses Google Gemini AI and Claude for analysis and content generation, with user authentication and database persistence.

## Project Structure
```
├── App.tsx              # Main React component with auth and navigation
├── index.tsx            # React entry point with QueryClientProvider
├── index.html           # HTML template with Tailwind CSS
├── types.ts             # TypeScript type definitions
├── vite.config.ts       # Vite configuration with API proxy
├── drizzle.config.ts    # Database migration config
├── components/
│   ├── Analyzer.tsx     # Video DNA Analyzer component
│   ├── GlassCard.tsx    # Reusable glass-style card component
│   ├── HookLibrary.tsx  # Hook library management (API-backed)
│   ├── KnowledgeBase.tsx # Training knowledge base (API-backed)
│   └── ScriptWriter.tsx # Script writing tool
├── hooks/
│   └── use-auth.ts      # Authentication hook
├── lib/
│   └── auth-utils.ts    # Auth utility functions
├── services/
│   ├── geminiService.ts # Google Gemini & Claude AI integration
│   └── api.ts           # API client for hooks/training
├── shared/
│   ├── schema.ts        # Drizzle database schema
│   └── models/
│       └── auth.ts      # Auth models (users, sessions)
└── server/
    ├── index.ts         # Express server entry point
    ├── db.ts            # Database connection
    ├── routes.ts        # API routes for hooks/training
    ├── storage.ts       # Database storage operations
    └── replit_integrations/
        └── auth/        # Replit Auth integration
```

## Tech Stack
- React 19 with TypeScript
- Vite 6 (build tool)
- Tailwind CSS (via CDN)
- Express.js (backend server)
- PostgreSQL with Drizzle ORM
- Replit Auth (login with Google, GitHub, etc.)
- Google Gemini AI (@google/genai)
- Claude AI (@anthropic-ai/sdk via Replit integration)
- TanStack Query (data fetching)
- Lucide React (icons)

## Environment Variables
- `GEMINI_API_KEY` - Required for AI features
- `AI_INTEGRATIONS_ANTHROPIC_API_KEY` - Auto-configured by Replit for Claude
- `DATABASE_URL` - Auto-configured PostgreSQL connection
- `SESSION_SECRET` - Auto-configured for auth sessions

## Running the App
The app runs both server and frontend with `npm run dev`:
- Express server on port 3001
- Vite dev server on port 5000 (proxies /api to server)

## Database
Run `npm run db:push` to sync schema changes to the database.

## Authentication
Users log in directly via Google OAuth (no Replit account required).
User data (hooks, training) is persisted per-user in PostgreSQL.

### Google OAuth Setup
1. Create a project in Google Cloud Console
2. Enable Google+ API or Google Identity API
3. Create OAuth 2.0 credentials with callback URLs:
   - Development: `https://{REPLIT_DEV_DOMAIN}/api/auth/google/callback`
   - Production: `https://{YOUR_PRODUCTION_DOMAIN}/api/auth/google/callback`
4. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to Secrets
5. Publish OAuth consent screen to production in Google Cloud Console

### Development
- Set `DEV_AUTH_BYPASS=true` in development environment to bypass login in the Replit iframe
