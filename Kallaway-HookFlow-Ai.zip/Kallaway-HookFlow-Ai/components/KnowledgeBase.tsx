import React, { useState, useEffect, useRef } from 'react';
import { BookOpen, Plus, Trash2, Save, Brain, GraduationCap, Link as LinkIcon, Loader2, FileText, Youtube, FolderOpen, ChevronRight, CheckCircle2, XCircle, Clock, ListPlus } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import GlassCard from './GlassCard';
import { api, TrainingItem, Framework } from '../services/api';
import { analyzeTrainingVideo } from '../services/geminiService';

interface QueueItem {
  id: string;
  url: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  title?: string;
  content?: string;
  error?: string;
}

const KnowledgeBase: React.FC = () => {
  const [selectedFramework, setSelectedFramework] = useState<Framework | null>(null);
  const [isAddingFramework, setIsAddingFramework] = useState(false);
  const [isAddingTraining, setIsAddingTraining] = useState(false);
  const [inputMode, setInputMode] = useState<'text' | 'url' | 'batch'>('text');
  
  const [newFrameworkName, setNewFrameworkName] = useState('');
  const [newFrameworkDesc, setNewFrameworkDesc] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [trainingUrl, setTrainingUrl] = useState('');
  const [batchUrls, setBatchUrls] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [isProcessingQueue, setIsProcessingQueue] = useState(false);
  const processingRef = useRef(false);

  const queryClient = useQueryClient();

  const { data: frameworks = [], isLoading: frameworksLoading } = useQuery({
    queryKey: ['frameworks'],
    queryFn: api.frameworks.list,
  });

  const { data: trainingItems = [], isLoading: trainingLoading } = useQuery({
    queryKey: ['training', selectedFramework?.id],
    queryFn: () => selectedFramework ? api.training.listByFramework(selectedFramework.id) : Promise.resolve([]),
    enabled: !!selectedFramework,
  });

  const createFrameworkMutation = useMutation({
    mutationFn: api.frameworks.create,
    onSuccess: (framework) => {
      queryClient.invalidateQueries({ queryKey: ['frameworks'] });
      setNewFrameworkName('');
      setNewFrameworkDesc('');
      setIsAddingFramework(false);
      setSelectedFramework(framework);
    },
  });

  const deleteFrameworkMutation = useMutation({
    mutationFn: api.frameworks.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['frameworks'] });
      setSelectedFramework(null);
    },
  });

  const createTrainingMutation = useMutation({
    mutationFn: api.training.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training', selectedFramework?.id] });
      setNewTitle('');
      setNewContent('');
      setTrainingUrl('');
      setInputMode('text');
      setIsAddingTraining(false);
    },
  });

  const deleteTrainingMutation = useMutation({
    mutationFn: api.training.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training', selectedFramework?.id] });
    },
  });

  const processQueue = async () => {
    if (processingRef.current || !selectedFramework) return;
    
    const pendingItems = queue.filter(item => item.status === 'pending');
    if (pendingItems.length === 0) {
      setIsProcessingQueue(false);
      return;
    }

    processingRef.current = true;
    setIsProcessingQueue(true);

    for (const item of pendingItems) {
      setQueue(prev => prev.map(q => 
        q.id === item.id ? { ...q, status: 'processing' as const } : q
      ));

      try {
        const result = await analyzeTrainingVideo(item.url);
        
        await api.training.create({
          title: result.title,
          content: result.content,
          frameworkId: selectedFramework.id
        });

        setQueue(prev => prev.map(q => 
          q.id === item.id ? { ...q, status: 'completed' as const, title: result.title, content: result.content } : q
        ));
        
        queryClient.invalidateQueries({ queryKey: ['training', selectedFramework?.id] });
      } catch (error) {
        setQueue(prev => prev.map(q => 
          q.id === item.id ? { ...q, status: 'failed' as const, error: 'Failed to analyze video' } : q
        ));
      }
    }

    processingRef.current = false;
    setIsProcessingQueue(false);
  };

  useEffect(() => {
    const hasPending = queue.some(item => item.status === 'pending');
    if (hasPending && !processingRef.current && selectedFramework) {
      processQueue();
    }
  }, [queue, selectedFramework]);

  const addToQueue = (urls: string[]) => {
    const newItems: QueueItem[] = urls
      .map(url => url.trim())
      .filter(url => url && (url.includes('youtube.com') || url.includes('youtu.be')))
      .map(url => ({
        id: Math.random().toString(36).substr(2, 9),
        url,
        status: 'pending' as const
      }));
    
    setQueue(prev => [...prev, ...newItems]);
    setBatchUrls('');
  };

  const handleUrlAnalysis = async () => {
    if (!trainingUrl) return;
    setIsAnalyzing(true);
    try {
      const result = await analyzeTrainingVideo(trainingUrl);
      setNewTitle(result.title);
      setNewContent(result.content);
      setInputMode('text');
      setTrainingUrl('');
    } catch (e) {
      alert("Failed to extract framework. Please check the URL or try pasting text manually.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSaveTraining = () => {
    if (!newTitle || !newContent || !selectedFramework) return;
    createTrainingMutation.mutate({ 
      title: newTitle, 
      content: newContent,
      frameworkId: selectedFramework.id 
    });
  };

  const handleDeleteTraining = (id: string) => {
    if (confirm('Are you sure you want to delete this training data?')) {
      deleteTrainingMutation.mutate(id);
    }
  };

  const handleDeleteFramework = (id: string) => {
    if (confirm('Are you sure you want to delete this framework and all its training data?')) {
      deleteFrameworkMutation.mutate(id);
    }
  };

  const clearCompletedQueue = () => {
    setQueue(prev => prev.filter(item => item.status !== 'completed'));
  };

  const pendingCount = queue.filter(q => q.status === 'pending').length;
  const processingCount = queue.filter(q => q.status === 'processing').length;
  const completedCount = queue.filter(q => q.status === 'completed').length;
  const failedCount = queue.filter(q => q.status === 'failed').length;

  if (frameworksLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-cyan-400">
            AI Training Center
          </h2>
          <p className="text-gray-400 mt-2">
            Organize your training data into frameworks for different content styles
          </p>
        </div>
      </div>

      {queue.length > 0 && (
        <GlassCard className="border border-purple-500/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold flex items-center gap-2">
              <ListPlus className="w-5 h-5 text-purple-400" />
              Import Queue
              {isProcessingQueue && (
                <span className="ml-2 text-sm text-purple-300 flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" /> Processing...
                </span>
              )}
            </h3>
            <div className="flex items-center gap-4 text-sm">
              {pendingCount > 0 && (
                <span className="flex items-center gap-1 text-gray-400">
                  <Clock className="w-4 h-4" /> {pendingCount} pending
                </span>
              )}
              {processingCount > 0 && (
                <span className="flex items-center gap-1 text-purple-400">
                  <Loader2 className="w-4 h-4 animate-spin" /> {processingCount} processing
                </span>
              )}
              {completedCount > 0 && (
                <span className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" /> {completedCount} done
                </span>
              )}
              {failedCount > 0 && (
                <span className="flex items-center gap-1 text-red-400">
                  <XCircle className="w-4 h-4" /> {failedCount} failed
                </span>
              )}
              {completedCount > 0 && (
                <button 
                  onClick={clearCompletedQueue}
                  className="text-xs text-gray-500 hover:text-white"
                >
                  Clear completed
                </button>
              )}
            </div>
          </div>
          
          <div className="max-h-48 overflow-y-auto space-y-2">
            {queue.map(item => (
              <div 
                key={item.id} 
                className={`flex items-center gap-3 p-2 rounded-lg text-sm ${
                  item.status === 'processing' ? 'bg-purple-500/10' :
                  item.status === 'completed' ? 'bg-emerald-500/10' :
                  item.status === 'failed' ? 'bg-red-500/10' :
                  'bg-white/5'
                }`}
              >
                {item.status === 'pending' && <Clock className="w-4 h-4 text-gray-400 flex-shrink-0" />}
                {item.status === 'processing' && <Loader2 className="w-4 h-4 text-purple-400 animate-spin flex-shrink-0" />}
                {item.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />}
                {item.status === 'failed' && <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />}
                
                <div className="flex-1 min-w-0">
                  {item.title ? (
                    <p className="font-medium truncate">{item.title}</p>
                  ) : (
                    <p className="text-gray-400 truncate">{item.url}</p>
                  )}
                  {item.error && <p className="text-xs text-red-400">{item.error}</p>}
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-emerald-400" />
              Frameworks
            </h3>
            <button
              onClick={() => setIsAddingFramework(true)}
              className="p-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 transition-all"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {isAddingFramework && (
            <GlassCard className="border-2 border-emerald-500/30">
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Framework name..."
                  value={newFrameworkName}
                  onChange={(e) => setNewFrameworkName(e.target.value)}
                  className="w-full p-2 rounded-lg glass-input text-sm"
                />
                <input
                  type="text"
                  placeholder="Description (optional)"
                  value={newFrameworkDesc}
                  onChange={(e) => setNewFrameworkDesc(e.target.value)}
                  className="w-full p-2 rounded-lg glass-input text-sm"
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsAddingFramework(false)}
                    className="flex-1 py-2 rounded-lg hover:bg-white/10 text-gray-300 text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => createFrameworkMutation.mutate({ 
                      name: newFrameworkName, 
                      description: newFrameworkDesc || null 
                    })}
                    disabled={!newFrameworkName || createFrameworkMutation.isPending}
                    className="flex-1 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 font-bold text-sm disabled:opacity-50"
                  >
                    Create
                  </button>
                </div>
              </div>
            </GlassCard>
          )}

          {frameworks.length === 0 && !isAddingFramework ? (
            <div className="p-6 text-center border-2 border-dashed border-white/5 rounded-xl text-gray-500">
              <FolderOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No frameworks yet</p>
              <p className="text-xs mt-1">Create one to get started</p>
            </div>
          ) : (
            <div className="space-y-2">
              {frameworks.map(framework => (
                <button
                  key={framework.id}
                  onClick={() => setSelectedFramework(framework)}
                  className={`w-full p-3 rounded-lg text-left transition-all flex items-center justify-between group ${
                    selectedFramework?.id === framework.id
                      ? 'bg-emerald-600/20 border border-emerald-500/50'
                      : 'bg-white/5 hover:bg-white/10 border border-transparent'
                  }`}
                >
                  <div>
                    <p className="font-medium">{framework.name}</p>
                    {framework.description && (
                      <p className="text-xs text-gray-400 mt-0.5">{framework.description}</p>
                    )}
                  </div>
                  <ChevronRight className={`w-4 h-4 transition-transform ${
                    selectedFramework?.id === framework.id ? 'rotate-90' : ''
                  }`} />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="md:col-span-2 space-y-4">
          {selectedFramework ? (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-xl">{selectedFramework.name}</h3>
                  {selectedFramework.description && (
                    <p className="text-sm text-gray-400">{selectedFramework.description}</p>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsAddingTraining(true)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 font-bold text-sm flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Add Training
                  </button>
                  <button
                    onClick={() => handleDeleteFramework(selectedFramework.id)}
                    className="p-2 rounded-lg hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {isAddingTraining && (
                <GlassCard className="border-2 border-emerald-500/30 animate-in slide-in-from-top-4">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <GraduationCap className="w-5 h-5 text-emerald-400" /> New Training Module
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="flex border-b border-white/10">
                      <button 
                        onClick={() => setInputMode('text')}
                        className={`px-4 py-2 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 ${inputMode === 'text' ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
                      >
                        <FileText className="w-4 h-4" /> Manual Entry
                      </button>
                      <button 
                        onClick={() => setInputMode('url')}
                        className={`px-4 py-2 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 ${inputMode === 'url' ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
                      >
                        <Youtube className="w-4 h-4" /> Single Video
                      </button>
                      <button 
                        onClick={() => setInputMode('batch')}
                        className={`px-4 py-2 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 ${inputMode === 'batch' ? 'border-purple-500 text-purple-400' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
                      >
                        <ListPlus className="w-4 h-4" /> Batch Import
                      </button>
                    </div>

                    {inputMode === 'batch' ? (
                      <div className="space-y-4 py-2">
                        <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg text-sm text-purple-200">
                          Paste multiple YouTube URLs (one per line). They'll be queued and processed in the background so you can keep working.
                        </div>
                        <div>
                          <label className="text-xs font-bold text-gray-400 uppercase">YouTube URLs (one per line)</label>
                          <textarea 
                            value={batchUrls}
                            onChange={(e) => setBatchUrls(e.target.value)}
                            placeholder="https://youtube.com/watch?v=...&#10;https://youtube.com/watch?v=...&#10;https://youtu.be/..."
                            className="w-full mt-1 p-3 h-32 rounded-lg glass-input font-mono text-sm"
                          />
                        </div>
                        <div className="flex gap-3">
                          <button 
                            onClick={() => setIsAddingTraining(false)}
                            className="px-4 py-2 rounded-lg hover:bg-white/10 text-gray-300"
                          >
                            Cancel
                          </button>
                          <button 
                            onClick={() => {
                              const urls = batchUrls.split('\n');
                              addToQueue(urls);
                              setIsAddingTraining(false);
                            }}
                            disabled={!batchUrls.trim()}
                            className="flex-1 py-3 rounded-lg bg-purple-600 hover:bg-purple-500 font-bold transition-all disabled:opacity-50 flex justify-center items-center gap-2"
                          >
                            <ListPlus className="w-5 h-5" />
                            Add {batchUrls.split('\n').filter(u => u.trim()).length} to Queue
                          </button>
                        </div>
                      </div>
                    ) : inputMode === 'url' ? (
                      <div className="space-y-4 py-2">
                        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-sm text-emerald-200">
                          Paste a URL to a training video. The AI will extract the key framework.
                        </div>
                        <div>
                          <label className="text-xs font-bold text-gray-400 uppercase">Training Video URL</label>
                          <div className="relative mt-1">
                            <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
                            <input 
                              type="text" 
                              placeholder="https://youtube.com/watch?v=..." 
                              value={trainingUrl}
                              onChange={(e) => setTrainingUrl(e.target.value)}
                              className="w-full pl-10 pr-4 py-3 rounded-lg glass-input"
                            />
                          </div>
                        </div>
                        <button 
                          onClick={handleUrlAnalysis}
                          disabled={isAnalyzing || !trainingUrl}
                          className="w-full py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 font-bold transition-all disabled:opacity-50 flex justify-center items-center gap-2"
                        >
                          {isAnalyzing ? <Loader2 className="animate-spin w-5 h-5" /> : <Brain className="w-5 h-5" />}
                          {isAnalyzing ? 'Extracting...' : 'Analyze & Extract'}
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <label className="text-xs font-bold text-gray-400 uppercase">Title</label>
                          <input 
                            type="text" 
                            placeholder="e.g., Hook Structure Rules" 
                            value={newTitle}
                            onChange={(e) => setNewTitle(e.target.value)}
                            className="w-full mt-1 p-3 rounded-lg glass-input"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-bold text-gray-400 uppercase">Content</label>
                          <textarea 
                            value={newContent}
                            onChange={(e) => setNewContent(e.target.value)}
                            placeholder="Paste the framework, rules, or transcript..."
                            className="w-full mt-1 p-3 h-48 rounded-lg glass-input font-mono text-sm"
                          />
                        </div>
                        
                        <div className="flex justify-end gap-3">
                          <button 
                            onClick={() => setIsAddingTraining(false)}
                            className="px-4 py-2 rounded-lg hover:bg-white/10 text-gray-300"
                          >
                            Cancel
                          </button>
                          <button 
                            onClick={handleSaveTraining}
                            disabled={!newTitle || !newContent || createTrainingMutation.isPending}
                            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 font-bold disabled:opacity-50 flex items-center gap-2"
                          >
                            {createTrainingMutation.isPending ? <Loader2 className="animate-spin w-4 h-4" /> : <Save className="w-4 h-4" />}
                            Save
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </GlassCard>
              )}

              {trainingLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
                </div>
              ) : trainingItems.length === 0 ? (
                <div className="p-12 text-center border-2 border-dashed border-white/5 rounded-xl text-gray-500">
                  <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-30" />
                  <p className="font-medium">No training data in this framework</p>
                  <p className="text-sm mt-1">Add content to train the AI on this style</p>
                </div>
              ) : (
                <div className="grid gap-3">
                  {trainingItems.map(item => (
                    <GlassCard key={item.id} className="group hover:border-emerald-500/50">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-emerald-100">{item.title}</h4>
                        <button 
                          onClick={() => handleDeleteTraining(item.id)} 
                          className="text-gray-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                          disabled={deleteTrainingMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-gray-400 line-clamp-3 font-mono bg-black/20 p-2 rounded">
                        {item.content}
                      </p>
                      {item.createdAt && (
                        <p className="text-xs text-gray-600 mt-2">
                          Added {new Date(item.createdAt).toLocaleDateString()}
                        </p>
                      )}
                    </GlassCard>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="flex items-center justify-center h-64 border-2 border-dashed border-white/5 rounded-xl">
              <div className="text-center text-gray-500">
                <Brain className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="font-medium">Select a framework</p>
                <p className="text-sm mt-1">Or create one to get started</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default KnowledgeBase;
