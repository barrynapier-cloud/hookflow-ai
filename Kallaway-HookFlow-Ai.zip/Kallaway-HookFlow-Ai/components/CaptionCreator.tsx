import React, { useState } from 'react';
import { Type, Sparkles, Copy, Check, RefreshCw, Loader2, FolderOpen, ChevronDown, Zap, Hash, AtSign, ShieldCheck } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import GlassCard from './GlassCard';
import { api, Framework } from '../services/api';
import { generateCaptions } from '../services/geminiService';

interface CaptionResult {
  title: string;
  caption: string;
  hashtags: string[];
  cta: string;
  complianceNotes: string[];
}

const CaptionCreator: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState<'youtube' | 'tiktok' | 'instagram' | 'twitter'>('youtube');
  const [tone, setTone] = useState<'bold' | 'curiosity' | 'controversial' | 'educational' | 'emotional'>('curiosity');
  const [selectedFramework, setSelectedFramework] = useState<Framework | null>(null);
  const [showFrameworkDropdown, setShowFrameworkDropdown] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [results, setResults] = useState<CaptionResult[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const { data: frameworks = [] } = useQuery({
    queryKey: ['frameworks'],
    queryFn: api.frameworks.list,
  });

  const { data: trainingItems = [] } = useQuery({
    queryKey: ['training', selectedFramework?.id],
    queryFn: () => selectedFramework ? api.training.listByFramework(selectedFramework.id) : Promise.resolve([]),
    enabled: !!selectedFramework,
  });

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    
    setIsGenerating(true);
    setResults([]);
    
    try {
      const trainingContext = trainingItems.length > 0 
        ? trainingItems.map(t => `### ${t.title}\n${t.content}`).join('\n\n')
        : '';

      const captions = await generateCaptions(topic, platform, tone, trainingContext);
      setResults(captions);
    } catch (error) {
      console.error('Caption generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const platformStyles = {
    youtube: { color: 'text-red-400', bg: 'bg-red-500/20', border: 'border-red-500/30' },
    tiktok: { color: 'text-pink-400', bg: 'bg-pink-500/20', border: 'border-pink-500/30' },
    instagram: { color: 'text-purple-400', bg: 'bg-purple-500/20', border: 'border-purple-500/30' },
    twitter: { color: 'text-blue-400', bg: 'bg-blue-500/20', border: 'border-blue-500/30' },
  };

  const toneLabels = {
    bold: 'Bold & Direct',
    curiosity: 'Curiosity Gap',
    controversial: 'Controversial',
    educational: 'Educational',
    emotional: 'Emotional',
  };

  return (
    <div className="w-full max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-orange-400">
            Caption Creator
          </h2>
          <p className="text-gray-400 mt-2">
            Generate scroll-stopping titles and captions
          </p>
        </div>

        <div className="relative">
          <button
            onClick={() => setShowFrameworkDropdown(!showFrameworkDropdown)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-sm transition-all"
          >
            <FolderOpen className="w-4 h-4 text-yellow-400" />
            {selectedFramework ? selectedFramework.name : 'No framework'}
            <ChevronDown className={`w-4 h-4 transition-transform ${showFrameworkDropdown ? 'rotate-180' : ''}`} />
          </button>

          {showFrameworkDropdown && (
            <div className="absolute right-0 mt-2 w-48 rounded-lg bg-slate-800 border border-white/10 shadow-xl z-20 overflow-hidden">
              <button
                onClick={() => {
                  setSelectedFramework(null);
                  setShowFrameworkDropdown(false);
                }}
                className={`w-full px-4 py-2 text-left text-sm hover:bg-white/10 transition-all ${
                  !selectedFramework ? 'bg-yellow-500/20 text-yellow-300' : 'text-gray-300'
                }`}
              >
                No framework
              </button>
              {frameworks.map(framework => (
                <button
                  key={framework.id}
                  onClick={() => {
                    setSelectedFramework(framework);
                    setShowFrameworkDropdown(false);
                  }}
                  className={`w-full px-4 py-2 text-left text-sm hover:bg-white/10 transition-all ${
                    selectedFramework?.id === framework.id ? 'bg-yellow-500/20 text-yellow-300' : 'text-gray-300'
                  }`}
                >
                  {framework.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <GlassCard className="mb-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">What's your video about?</label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Describe your video content, key message, or paste your script..."
              className="w-full p-4 rounded-xl glass-input text-sm h-24 resize-none"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Platform</label>
              <div className="grid grid-cols-2 gap-2">
                {(['youtube', 'tiktok', 'instagram', 'twitter'] as const).map((p) => (
                  <button
                    key={p}
                    onClick={() => setPlatform(p)}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all capitalize ${
                      platform === p 
                        ? `${platformStyles[p].bg} ${platformStyles[p].color} ${platformStyles[p].border} border` 
                        : 'bg-white/5 text-gray-400 hover:bg-white/10'
                    }`}
                  >
                    {p === 'twitter' ? 'X / Twitter' : p}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Tone</label>
              <div className="flex flex-wrap gap-2">
                {(['bold', 'curiosity', 'controversial', 'educational', 'emotional'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTone(t)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      tone === t 
                        ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30' 
                        : 'bg-white/5 text-gray-400 hover:bg-white/10'
                    }`}
                  >
                    {toneLabels[t]}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={!topic.trim() || isGenerating}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500 font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Zap className="w-5 h-5" />
                Generate Captions
              </>
            )}
          </button>
        </div>
      </GlassCard>

      {results.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-yellow-400" />
            Generated Captions
          </h3>

          {results.map((result, index) => (
            <GlassCard key={index} className="group hover:border-yellow-500/30">
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-yellow-400 uppercase flex items-center gap-1">
                      <Type className="w-3 h-3" /> Title
                    </label>
                    <button
                      onClick={() => copyToClipboard(result.title, index * 10)}
                      className="text-gray-500 hover:text-white transition-all"
                    >
                      {copiedIndex === index * 10 ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-lg font-bold">{result.title}</p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-orange-400 uppercase flex items-center gap-1">
                      <AtSign className="w-3 h-3" /> Caption
                    </label>
                    <button
                      onClick={() => copyToClipboard(result.caption, index * 10 + 1)}
                      className="text-gray-500 hover:text-white transition-all"
                    >
                      {copiedIndex === index * 10 + 1 ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-gray-300 text-sm whitespace-pre-wrap">{result.caption}</p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-blue-400 uppercase flex items-center gap-1">
                      <Hash className="w-3 h-3" /> Hashtags
                    </label>
                    <button
                      onClick={() => copyToClipboard(result.hashtags.join(' '), index * 10 + 2)}
                      className="text-gray-500 hover:text-white transition-all"
                    >
                      {copiedIndex === index * 10 + 2 ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {result.hashtags.map((tag, i) => (
                      <span key={i} className="px-2 py-1 rounded-full bg-blue-500/10 text-blue-300 text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-white/10">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-green-400 uppercase">Call to Action</label>
                    <button
                      onClick={() => copyToClipboard(result.cta, index * 10 + 3)}
                      className="text-gray-500 hover:text-white transition-all"
                    >
                      {copiedIndex === index * 10 + 3 ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-green-300 text-sm italic">{result.cta}</p>
                </div>

                {result.complianceNotes && result.complianceNotes.length > 0 && (
                  <div className="pt-3 border-t border-white/10">
                    <label className="text-xs font-bold text-purple-400 uppercase flex items-center gap-1 mb-2">
                      <ShieldCheck className="w-3 h-3" /> Compliance Check
                    </label>
                    <div className="space-y-1">
                      {result.complianceNotes.map((note, i) => (
                        <p key={i} className="text-xs text-gray-400 flex items-start gap-2">
                          <span className="text-purple-400 mt-0.5">•</span>
                          {note}
                        </p>
                      ))}
                    </div>
                  </div>
                )}

                <button
                  onClick={() => copyToClipboard(`${result.title}\n\n${result.caption}\n\n${result.hashtags.join(' ')}\n\n${result.cta}`, index * 10 + 4)}
                  className="w-full py-2 rounded-lg bg-white/5 hover:bg-white/10 text-sm font-semibold transition-all flex items-center justify-center gap-2"
                >
                  {copiedIndex === index * 10 + 4 ? (
                    <>
                      <Check className="w-4 h-4 text-green-400" />
                      Copied All!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copy Everything
                    </>
                  )}
                </button>
              </div>
            </GlassCard>
          ))}

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 font-semibold transition-all flex items-center justify-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            Generate More
          </button>
        </div>
      )}
    </div>
  );
};

export default CaptionCreator;
