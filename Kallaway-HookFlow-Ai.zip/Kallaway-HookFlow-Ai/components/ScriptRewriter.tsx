import React, { useState, useEffect } from 'react';
import { RefreshCw, Sparkles, Copy, Check, Brain, Search, Lightbulb, Wand2, FolderOpen, Loader2 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import GlassCard from './GlassCard';
import { rewriteScript } from '../services/geminiService';
import { api, Framework } from '../services/api';

const ThinkingAnimation: React.FC<{ message: string }> = ({ message }) => {
  const [dotCount, setDotCount] = useState(0);
  const [phaseIndex, setPhaseIndex] = useState(0);
  
  const phases = [
    { icon: Search, label: "Analyzing structure", color: "text-blue-400" },
    { icon: Brain, label: "Identifying improvements", color: "text-purple-400" },
    { icon: Lightbulb, label: "Enhancing hooks", color: "text-yellow-400" },
    { icon: Sparkles, label: "Polishing script", color: "text-pink-400" },
  ];

  useEffect(() => {
    const dotInterval = setInterval(() => {
      setDotCount(d => (d + 1) % 4);
    }, 400);
    
    const phaseInterval = setInterval(() => {
      setPhaseIndex(p => (p + 1) % phases.length);
    }, 2500);
    
    return () => {
      clearInterval(dotInterval);
      clearInterval(phaseInterval);
    };
  }, []);

  const CurrentIcon = phases[phaseIndex].icon;

  return (
    <div className="py-8">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <div className="absolute inset-0 w-20 h-20 rounded-full bg-purple-500/20 animate-ping" style={{ animationDuration: '2s' }} />
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center shadow-lg shadow-purple-500/50">
            <CurrentIcon className="w-8 h-8 text-white" />
          </div>
          <div className="absolute inset-0 animate-spin" style={{ animationDuration: '3s' }}>
            <div className="absolute -top-1 left-1/2 w-2 h-2 -ml-1 rounded-full bg-blue-400" />
          </div>
        </div>
        <p className={`text-lg font-semibold ${phases[phaseIndex].color}`}>
          {phases[phaseIndex].label}{'.'.repeat(dotCount)}
        </p>
        {message && (
          <p className="text-sm text-gray-400 font-mono bg-black/30 rounded-lg px-3 py-2">
            {message}
          </p>
        )}
      </div>
    </div>
  );
};

const ScriptRewriter: React.FC = () => {
  const [originalScript, setOriginalScript] = useState('');
  const [rewrittenScript, setRewrittenScript] = useState('');
  const [instructions, setInstructions] = useState('');
  const [isRewriting, setIsRewriting] = useState(false);
  const [progressMsg, setProgressMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const [selectedFramework, setSelectedFramework] = useState<Framework | null>(null);

  const { data: frameworks = [], isLoading: frameworksLoading } = useQuery({
    queryKey: ['frameworks'],
    queryFn: api.frameworks.list,
  });

  const presetInstructions = [
    { label: "Make it more engaging", prompt: "Make this script more engaging and attention-grabbing. Add pattern interrupts and emotional hooks." },
    { label: "Strengthen the hook", prompt: "Rewrite with a much stronger opening hook that creates immediate curiosity or urgency." },
    { label: "Add more storytelling", prompt: "Weave in storytelling elements - use specific examples, anecdotes, or case studies to make points more memorable." },
    { label: "Simplify language", prompt: "Simplify the language for a broader audience. Remove jargon and use conversational, easy-to-understand words." },
    { label: "Increase urgency", prompt: "Add more urgency and stakes. Make the viewer feel they need to act or learn this now." },
    { label: "Make it shorter", prompt: "Condense this script significantly while keeping the core message and impact. Remove filler and redundancy." },
  ];

  const handleRewrite = async (customInstructions?: string) => {
    if (!originalScript.trim()) return;
    
    const finalInstructions = customInstructions || instructions || "Improve this script to be more engaging, viral, and impactful.";
    
    setIsRewriting(true);
    setProgressMsg('Analyzing original script...');
    
    try {
      const result = await rewriteScript(
        originalScript,
        finalInstructions,
        (msg) => setProgressMsg(msg),
        selectedFramework?.id
      );
      setRewrittenScript(result);
    } catch (error) {
      console.error('Rewrite failed:', error);
      setProgressMsg('Failed to rewrite script. Please try again.');
    } finally {
      setIsRewriting(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(rewrittenScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-pink-400">
          Script Rewriter
        </h2>
        <p className="text-gray-400 mt-2">Paste your script and let AI transform it into viral-worthy content.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <GlassCard className="h-full flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <RefreshCw className="w-5 h-5 text-orange-400" /> Original Script
              </h3>
              <span className="text-xs text-gray-500">{originalScript.length} chars</span>
            </div>
            
            <textarea
              value={originalScript}
              onChange={(e) => setOriginalScript(e.target.value)}
              placeholder="Paste your existing script here..."
              className="flex-1 w-full p-4 rounded-xl glass-input text-sm placeholder-gray-600 min-h-[300px] resize-none"
            />

            <div className="mt-4 space-y-4">
              <div>
                <label className="text-sm font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                  <FolderOpen className="w-4 h-4" /> Apply Framework Style
                </label>
                <p className="text-xs text-gray-500 mb-2">Use your training data to guide the rewrite</p>
                {frameworksLoading ? (
                  <div className="flex items-center gap-2 text-gray-500">
                    <Loader2 className="w-4 h-4 animate-spin" /> Loading...
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => setSelectedFramework(null)}
                      className={`px-3 py-1.5 rounded-lg text-xs transition-all ${
                        !selectedFramework 
                          ? 'bg-orange-600 text-white' 
                          : 'bg-white/5 text-gray-400 hover:bg-white/10'
                      }`}
                    >
                      None
                    </button>
                    {frameworks.map(fw => (
                      <button
                        key={fw.id}
                        onClick={() => setSelectedFramework(fw)}
                        className={`px-3 py-1.5 rounded-lg text-xs transition-all ${
                          selectedFramework?.id === fw.id 
                            ? 'bg-orange-600 text-white' 
                            : 'bg-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        {fw.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Rewrite Instructions (optional)</label>
                <input
                  type="text"
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder="e.g., Make it funnier and add more hooks..."
                  className="w-full p-3 rounded-xl glass-input text-sm placeholder-gray-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                {presetInstructions.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => handleRewrite(preset.prompt)}
                    disabled={isRewriting || !originalScript.trim()}
                    className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-left transition-all border border-white/5 hover:border-orange-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <span className="text-xs font-semibold text-orange-300">{preset.label}</span>
                  </button>
                ))}
              </div>

              <button
                onClick={() => handleRewrite()}
                disabled={isRewriting || !originalScript.trim()}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-600 to-pink-600 font-bold hover:opacity-90 transition-all disabled:opacity-50 flex justify-center items-center gap-2"
              >
                {isRewriting ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
                {isRewriting ? 'Rewriting...' : 'Rewrite Script'}
              </button>
            </div>
          </GlassCard>
        </div>

        <div className="space-y-4">
          <GlassCard className="h-full flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-pink-400" /> Improved Script
              </h3>
              {rewrittenScript && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-xs text-gray-400 hover:text-white transition-colors px-2 py-1 rounded bg-white/5"
                >
                  {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                  {copied ? 'Copied!' : 'Copy'}
                </button>
              )}
            </div>

            {isRewriting ? (
              <ThinkingAnimation message={progressMsg} />
            ) : rewrittenScript ? (
              <div className="flex-1 overflow-y-auto">
                <div className="prose prose-invert prose-sm max-w-none whitespace-pre-wrap text-gray-200 leading-relaxed">
                  {rewrittenScript}
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-600">
                <div className="text-center">
                  <Wand2 className="w-12 h-12 mx-auto mb-4 opacity-30" />
                  <p>Your improved script will appear here</p>
                  <p className="text-sm mt-2">Paste a script and click rewrite to get started</p>
                </div>
              </div>
            )}
          </GlassCard>
        </div>
      </div>
    </div>
  );
};

export default ScriptRewriter;
