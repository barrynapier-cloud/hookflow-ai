import React, { useState, useEffect } from 'react';
import { FileText, Settings, Zap, CheckCircle2, RefreshCw, ArrowRight, Sparkles, ArrowLeft, FolderOpen, Loader2, Brain, Search, Lightbulb } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import GlassCard from './GlassCard';
import HookLibrary from './HookLibrary';
import { Hook, ResearchConfig, GenerationStatus, ViralIdea } from '../types';
import { generateViralIdeas, remixViralIdea, writeFinalScript } from '../services/geminiService';
import { api, Framework } from '../services/api';

// Thinking Animation Component
const ThinkingAnimation: React.FC<{ progressMsg: string }> = ({ progressMsg }) => {
  const [dotCount, setDotCount] = useState(0);
  const [phaseIndex, setPhaseIndex] = useState(0);
  
  const phases = [
    { icon: Search, label: "Researching", color: "text-blue-400" },
    { icon: Brain, label: "Analyzing", color: "text-purple-400" },
    { icon: Lightbulb, label: "Generating ideas", color: "text-yellow-400" },
    { icon: Sparkles, label: "Crafting hooks", color: "text-pink-400" },
  ];

  useEffect(() => {
    const dotInterval = setInterval(() => {
      setDotCount(d => (d + 1) % 4);
    }, 400);
    
    const phaseInterval = setInterval(() => {
      setPhaseIndex(p => (p + 1) % phases.length);
    }, 2500);
    
    return () => {
      clearInterval(dotInterval);
      clearInterval(phaseInterval);
    };
  }, []);

  const CurrentIcon = phases[phaseIndex].icon;

  return (
    <div className="mt-8">
      <GlassCard className="max-w-md mx-auto overflow-hidden">
        {/* Animated gradient border */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 opacity-20 animate-pulse" />
        
        <div className="relative z-10 py-6 px-4">
          {/* Central brain animation */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              {/* Outer pulsing ring */}
              <div className="absolute inset-0 w-24 h-24 rounded-full bg-purple-500/20 animate-ping" style={{ animationDuration: '2s' }} />
              <div className="absolute inset-2 w-20 h-20 rounded-full bg-purple-500/30 animate-ping" style={{ animationDuration: '1.5s', animationDelay: '0.2s' }} />
              
              {/* Center icon container */}
              <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center shadow-lg shadow-purple-500/50">
                <CurrentIcon className={`w-10 h-10 text-white transition-all duration-500`} />
              </div>
              
              {/* Orbiting dots */}
              <div className="absolute inset-0 animate-spin" style={{ animationDuration: '3s' }}>
                <div className="absolute -top-1 left-1/2 w-3 h-3 -ml-1.5 rounded-full bg-blue-400 shadow-lg shadow-blue-400/50" />
              </div>
              <div className="absolute inset-0 animate-spin" style={{ animationDuration: '4s', animationDirection: 'reverse' }}>
                <div className="absolute -bottom-1 left-1/2 w-2 h-2 -ml-1 rounded-full bg-pink-400 shadow-lg shadow-pink-400/50" />
              </div>
              <div className="absolute inset-0 animate-spin" style={{ animationDuration: '5s' }}>
                <div className="absolute top-1/2 -right-1 w-2 h-2 -mt-1 rounded-full bg-yellow-400 shadow-lg shadow-yellow-400/50" />
              </div>
            </div>
          </div>

          {/* Phase indicator */}
          <div className="text-center mb-4">
            <p className={`text-lg font-semibold ${phases[phaseIndex].color} transition-colors duration-500`}>
              {phases[phaseIndex].label}{'.'.repeat(dotCount)}
            </p>
          </div>

          {/* Progress message */}
          {progressMsg && (
            <div className="text-center">
              <p className="text-sm text-gray-400 font-mono bg-black/30 rounded-lg px-3 py-2 inline-block">
                {progressMsg}
              </p>
            </div>
          )}

          {/* Phase dots */}
          <div className="flex justify-center gap-2 mt-4">
            {phases.map((_, idx) => (
              <div 
                key={idx} 
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  idx === phaseIndex 
                    ? 'bg-purple-400 scale-125' 
                    : 'bg-gray-600'
                }`} 
              />
            ))}
          </div>
        </div>
      </GlassCard>
    </div>
  );
};

const ScriptWriter: React.FC = () => {
  // Workflow State: 'config' -> 'ideation' -> 'refinement' -> 'scripting'
  const [phase, setPhase] = useState<'config' | 'ideation' | 'refinement' | 'scripting'>('config');
  
  // Data State
  const [topic, setTopic] = useState('');
  const [ideas, setIdeas] = useState<ViralIdea[]>([]);
  const [selectedIdea, setSelectedIdea] = useState<ViralIdea | null>(null);
  const [selectedHookPattern, setSelectedHookPattern] = useState<Hook | null>(null);
  const [selectedFramework, setSelectedFramework] = useState<Framework | null>(null);
  const [researchNotes, setResearchNotes] = useState('');
  const [generatedScript, setGeneratedScript] = useState('');
  
  // Fetch frameworks
  const { data: frameworks = [], isLoading: frameworksLoading } = useQuery({
    queryKey: ['frameworks'],
    queryFn: api.frameworks.list,
  });

  // Status & UI
  const [status, setStatus] = useState<GenerationStatus>(GenerationStatus.IDLE);
  const [progressMsg, setProgressMsg] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [isRemixing, setIsRemixing] = useState(false);

  const [config, setConfig] = useState<ResearchConfig>({
    useGemini: true,
    useClaude: true,
    usePerplexity: true,
    thinkingBudget: 4096
  });

  // --- Phase 1: Generate Ideas ---
  const handleGenerateIdeas = async () => {
    if (!topic) return;
    setStatus(GenerationStatus.RESEARCHING);
    setPhase('ideation');
    
    try {
      const result = await generateViralIdeas(
        topic, 
        config, 
        (msg) => setProgressMsg(msg),
        selectedFramework?.id
      );
      setIdeas(result.ideas);
      setResearchNotes(result.researchSummary);
      setStatus(GenerationStatus.IDEATION_COMPLETE);
    } catch (e) {
      console.error(e);
      setStatus(GenerationStatus.ERROR);
      setProgressMsg("Failed to generate ideas.");
    }
  };

  // --- Phase 2: Refinement (Remix) ---
  const handleSelectIdea = (idea: ViralIdea) => {
    setSelectedIdea(idea);
    setPhase('refinement');
  };

  const handleRemix = async (instruction: string) => {
    if (!selectedIdea) return;
    setIsRemixing(true);
    try {
        const updatedIdea = await remixViralIdea(
          selectedIdea, 
          instruction, 
          researchNotes,
          selectedFramework?.id
        );
        setSelectedIdea(updatedIdea);
        setIdeas(prev => prev.map(i => i.id === updatedIdea.id ? updatedIdea : i));
    } catch (e) {
        alert("Failed to remix idea");
    } finally {
        setIsRemixing(false);
        setChatInput('');
    }
  };

  const kallawayPresets = [
    { label: "Make it High Stakes", prompt: "Rewrite this idea to emphasize the immediate 'High Stakes' or fear of loss. Why does this matter RIGHT NOW?" },
    { label: "Visual Pattern Interrupt", prompt: "Change the Hook Concept to be a purely Visual Pattern Interrupt that stops the scroll immediately." },
    { label: "Make it Contrarian", prompt: "Flip the angle to be controversial or contrarian to popular belief." }
  ];

  // --- Phase 3: Final Script ---
  const handleWriteScript = async () => {
    if (!selectedIdea) return;
    setStatus(GenerationStatus.WRITING);
    setPhase('scripting');
    setProgressMsg("Writing final script...");

    try {
        const script = await writeFinalScript(
          selectedIdea, 
          selectedHookPattern, 
          researchNotes,
          selectedFramework?.id
        );
        setGeneratedScript(script);
        setStatus(GenerationStatus.SUCCESS);
    } catch (e) {
        setStatus(GenerationStatus.ERROR);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      
      {/* Progress Stepper */}
      <div className="flex justify-between items-center mb-8 px-4 max-w-3xl mx-auto">
        {['Research & Config', 'Select Idea', 'Remix Lab', 'Final Script'].map((label, idx) => {
           const stepPhases = ['config', 'ideation', 'refinement', 'scripting'];
           const currentIndex = stepPhases.indexOf(phase);
           const isActive = idx === currentIndex;
           const isDone = idx < currentIndex;
           
           return (
               <div key={label} className={`flex items-center gap-2 ${isActive ? 'text-purple-400 font-bold' : isDone ? 'text-emerald-400' : 'text-gray-600'}`}>
                   <div className={`w-8 h-8 rounded-full flex items-center justify-center border ${isActive ? 'border-purple-400 bg-purple-400/20' : isDone ? 'border-emerald-400 bg-emerald-400/20' : 'border-gray-700 bg-gray-800'}`}>
                       {isDone ? <CheckCircle2 className="w-4 h-4" /> : <span>{idx + 1}</span>}
                   </div>
                   <span className="hidden md:inline text-sm">{label}</span>
               </div>
           )
        })}
      </div>

      {/* PHASE 1: CONFIG */}
      {phase === 'config' && (
        <div className="max-w-2xl mx-auto">
             <div className="text-center mb-8">
                <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
                    Viral Research Engine
                </h2>
                <p className="text-gray-400 mt-2">Deploy AI agents to find the winning angle before you write.</p>
            </div>

            <GlassCard className="space-y-6">
                <div>
                    <label className="text-sm font-bold text-gray-300 uppercase tracking-wider">Topic / Core Idea</label>
                    <textarea 
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder="e.g. The hidden psychology of pricing..."
                        className="w-full mt-2 p-4 h-32 rounded-xl glass-input text-lg placeholder-gray-600"
                    />
                </div>

                <div>
                    <label className="text-sm font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                        <FolderOpen className="w-4 h-4" /> Training Framework
                    </label>
                    <p className="text-xs text-gray-500 mb-2">Select a framework to apply its training data to all AI outputs</p>
                    {frameworksLoading ? (
                        <div className="flex items-center gap-2 text-gray-500">
                            <Loader2 className="w-4 h-4 animate-spin" /> Loading...
                        </div>
                    ) : frameworks.length === 0 ? (
                        <p className="text-sm text-gray-500 italic">No frameworks yet. Create one in the Training tab.</p>
                    ) : (
                        <div className="flex flex-wrap gap-2">
                            <button
                                onClick={() => setSelectedFramework(null)}
                                className={`px-3 py-2 rounded-lg text-sm transition-all ${
                                    !selectedFramework 
                                        ? 'bg-purple-600 text-white' 
                                        : 'bg-white/5 text-gray-400 hover:bg-white/10'
                                }`}
                            >
                                None
                            </button>
                            {frameworks.map(fw => (
                                <button
                                    key={fw.id}
                                    onClick={() => setSelectedFramework(fw)}
                                    className={`px-3 py-2 rounded-lg text-sm transition-all ${
                                        selectedFramework?.id === fw.id 
                                            ? 'bg-purple-600 text-white' 
                                            : 'bg-white/5 text-gray-400 hover:bg-white/10'
                                    }`}
                                >
                                    {fw.name}
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase">Research Agents</label>
                        <div className="flex flex-col gap-2">
                            <label className="flex items-center gap-2 p-2 rounded bg-white/5 border border-white/5">
                                <input type="checkbox" checked={config.useGemini} onChange={e => setConfig({...config, useGemini: e.target.checked})} className="accent-purple-500"/>
                                <span className="text-sm">Gemini (Deep Fact Check)</span>
                            </label>
                            <label className="flex items-center gap-2 p-2 rounded bg-white/5 border border-white/5">
                                <input type="checkbox" checked={config.usePerplexity} onChange={e => setConfig({...config, usePerplexity: e.target.checked})} className="accent-teal-500"/>
                                <span className="text-sm">Perplexity (Sources)</span>
                            </label>
                             <label className="flex items-center gap-2 p-2 rounded bg-white/5 border border-white/5">
                                <input type="checkbox" checked={config.useClaude} onChange={e => setConfig({...config, useClaude: e.target.checked})} className="accent-orange-500"/>
                                <span className="text-sm">Claude (Psychology)</span>
                            </label>
                        </div>
                     </div>
                     <div className="space-y-2">
                         <label className="text-xs font-bold text-gray-500 uppercase">Pro Thinking Budget</label>
                         <input 
                            type="range" 
                            min="2048" 
                            max="8192" 
                            step="1024" 
                            value={config.thinkingBudget}
                            onChange={(e) => setConfig({...config, thinkingBudget: parseInt(e.target.value)})}
                            className="w-full accent-purple-500 mt-4"
                        />
                        <div className="text-right text-xs text-purple-300">{config.thinkingBudget} tokens</div>
                     </div>
                </div>

                <button 
                    onClick={handleGenerateIdeas}
                    disabled={status === GenerationStatus.RESEARCHING || !topic}
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 font-bold text-lg hover:opacity-90 transition-all disabled:opacity-50 flex justify-center items-center gap-2 shadow-lg shadow-purple-500/20"
                >
                    {status === GenerationStatus.RESEARCHING ? <RefreshCw className="animate-spin" /> : <Zap />}
                    {status === GenerationStatus.RESEARCHING ? 'Researching & Ideating...' : 'Generate 10 Viral Ideas'}
                </button>
            </GlassCard>

             {status === GenerationStatus.RESEARCHING && (
                 <ThinkingAnimation progressMsg={progressMsg} />
             )}
        </div>
      )}

      {/* PHASE 2: IDEATION LIST */}
      {phase === 'ideation' && (
          <div className="space-y-6">
               <div className="flex justify-between items-end">
                   <div>
                       <h3 className="text-2xl font-bold text-white">Top 10 Research-Backed Ideas</h3>
                       <p className="text-gray-400">Select an idea to refine and remix.</p>
                   </div>
                   <button onClick={() => setPhase('config')} className="text-sm text-gray-500 hover:text-white flex items-center gap-1">
                       <ArrowLeft className="w-4 h-4" /> Back to Research
                   </button>
               </div>

               <div className="grid md:grid-cols-2 gap-4">
                   {ideas.map((idea, idx) => (
                       <GlassCard 
                            key={idea.id} 
                            onClick={() => handleSelectIdea(idea)}
                            hoverEffect
                            className="cursor-pointer border-l-4 border-l-transparent hover:border-l-purple-500"
                        >
                           <div className="flex justify-between mb-2">
                               <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">Option #{idx + 1}</span>
                               <span className="text-xs bg-white/10 px-2 py-1 rounded text-gray-300">{idea.angle}</span>
                           </div>
                           <h4 className="text-xl font-bold mb-3">{idea.headline}</h4>
                           <div className="mb-3 p-3 bg-black/20 rounded-lg">
                               <span className="text-xs text-gray-500 uppercase font-bold">Hook Concept</span>
                               <p className="text-sm text-gray-200 italic">"{idea.hookConcept}"</p>
                           </div>
                           <p className="text-xs text-gray-400 line-clamp-2"><span className="text-emerald-500 font-bold">Fact:</span> {idea.researchFact}</p>
                       </GlassCard>
                   ))}
               </div>
          </div>
      )}

      {/* PHASE 3: REFINEMENT (THE LAB) */}
      {phase === 'refinement' && selectedIdea && (
          <div className="grid lg:grid-cols-2 gap-8 h-[600px]">
              {/* Left: The Idea Card */}
              <div className="space-y-4">
                  <button onClick={() => setPhase('ideation')} className="text-sm text-gray-500 hover:text-white flex items-center gap-1 mb-2">
                       <ArrowLeft className="w-4 h-4" /> Back to List
                   </button>
                  <GlassCard className="h-full border-t-4 border-t-purple-500 flex flex-col">
                      <div className="flex-1 space-y-6">
                           <div>
                               <label className="text-xs font-bold text-gray-500 uppercase">Headline</label>
                               <h2 className="text-2xl font-bold text-white leading-tight">{selectedIdea.headline}</h2>
                           </div>
                           
                           <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-xl">
                               <label className="text-xs font-bold text-purple-300 uppercase flex items-center gap-2">
                                   <Sparkles className="w-3 h-3" /> Viral Hook
                                </label>
                               <p className="text-lg text-purple-100 italic mt-1 font-serif">"{selectedIdea.hookConcept}"</p>
                           </div>

                           <div className="grid grid-cols-2 gap-4">
                               <div className="p-3 bg-white/5 rounded-lg">
                                   <label className="text-xs font-bold text-gray-500 uppercase">Angle</label>
                                   <p className="text-sm text-gray-300">{selectedIdea.angle}</p>
                               </div>
                               <div className="p-3 bg-white/5 rounded-lg">
                                   <label className="text-xs font-bold text-gray-500 uppercase">Validation</label>
                                   <p className="text-sm text-gray-300">{selectedIdea.whyItWorks}</p>
                               </div>
                           </div>
                           
                           <div className="p-3 bg-emerald-900/20 border border-emerald-500/20 rounded-lg">
                                <label className="text-xs font-bold text-emerald-400 uppercase">Verified Research</label>
                                <p className="text-sm text-emerald-100/80 mt-1">{selectedIdea.researchFact}</p>
                           </div>
                      </div>

                      <button 
                        onClick={handleWriteScript}
                        className="w-full mt-6 py-3 rounded-xl bg-white text-black font-bold hover:bg-gray-200 transition-all flex justify-center items-center gap-2"
                      >
                          <FileText className="w-5 h-5" /> Generate Final Script
                      </button>
                  </GlassCard>
              </div>

              {/* Right: The Remix Chat */}
              <div className="flex flex-col h-full">
                  <GlassCard className="flex-1 flex flex-col relative overflow-hidden">
                      <div className="flex items-center gap-2 mb-4 pb-4 border-b border-white/10">
                          <RefreshCw className="w-5 h-5 text-pink-400" />
                          <h3 className="font-bold">Idea Remix Lab</h3>
                      </div>
                      
                      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
                          <p className="text-sm text-gray-400 text-center italic">
                              Need a different take? Use the presets or chat below to remix this idea.
                          </p>
                          
                          <div className="grid grid-cols-1 gap-2">
                              {kallawayPresets.map((preset) => (
                                  <button 
                                    key={preset.label}
                                    onClick={() => handleRemix(preset.prompt)}
                                    disabled={isRemixing}
                                    className="p-3 rounded-lg bg-white/5 hover:bg-white/10 text-left transition-all border border-white/5 hover:border-purple-500/50 group"
                                  >
                                      <div className="font-bold text-sm text-purple-300 group-hover:text-purple-200">{preset.label}</div>
                                      <div className="text-xs text-gray-500 truncate">{preset.prompt}</div>
                                  </button>
                              ))}
                          </div>
                      </div>

                      <div className="relative">
                          <input 
                            type="text" 
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleRemix(chatInput)}
                            placeholder="e.g. Make it more emotional..."
                            className="w-full pl-4 pr-12 py-3 rounded-xl glass-input text-sm"
                            disabled={isRemixing}
                          />
                          <button 
                            onClick={() => handleRemix(chatInput)}
                            disabled={!chatInput || isRemixing}
                            className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 transition-all disabled:opacity-50"
                          >
                             {isRemixing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                          </button>
                      </div>
                  </GlassCard>
                  
                  {/* Optional: Select Hook Pattern override */}
                  <div className="mt-4">
                      <details className="group">
                          <summary className="list-none cursor-pointer text-xs font-bold text-gray-500 uppercase flex items-center gap-2 hover:text-purple-400 transition-colors">
                              <Settings className="w-3 h-3" /> Advanced: Override Hook Pattern
                          </summary>
                          <div className="mt-2 p-4 glass-panel rounded-xl absolute bottom-20 right-0 left-0 z-50 bg-[#0f172a] border border-white/20 shadow-2xl h-96 overflow-y-auto">
                              <HookLibrary selectionMode onSelectHook={(h) => { setSelectedHookPattern(h); alert(`Hook Pattern Applied: ${h.title}`); }} />
                          </div>
                      </details>
                  </div>
              </div>
          </div>
      )}

      {/* PHASE 4: FINAL SCRIPT */}
      {phase === 'scripting' && (
          <div className="space-y-6 animate-in slide-in-from-right-8">
               <button onClick={() => setPhase('refinement')} className="text-sm text-gray-500 hover:text-white flex items-center gap-1">
                       <ArrowLeft className="w-4 h-4" /> Back to Lab
               </button>
               <GlassCard className="min-h-[500px]">
                   <div className="flex justify-between items-center mb-6 pb-6 border-b border-white/10">
                       <h2 className="text-2xl font-bold flex items-center gap-2">
                           <FileText className="w-6 h-6 text-emerald-400" /> Final Script
                       </h2>
                       <div className="flex gap-2">
                           <span className="px-3 py-1 rounded-full bg-white/10 text-xs text-gray-400">Gemini Pro Thinking</span>
                           <span className="px-3 py-1 rounded-full bg-white/10 text-xs text-gray-400">Multi-Agent Research</span>
                       </div>
                   </div>
                   
                   <div className="prose prose-invert prose-p:text-gray-300 prose-headings:text-white max-w-none whitespace-pre-wrap font-sans text-lg leading-relaxed">
                       {generatedScript}
                   </div>
               </GlassCard>

               <GlassCard className="bg-white/5">
                    <h3 className="text-sm font-bold text-gray-500 uppercase mb-4">Research References Used</h3>
                    <div className="prose prose-sm prose-invert max-w-none text-gray-400 max-h-48 overflow-y-auto">
                        {researchNotes}
                    </div>
               </GlassCard>
          </div>
      )}
    </div>
  );
};

export default ScriptWriter;