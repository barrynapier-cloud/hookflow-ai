import React, { useState } from 'react';
import { ArrowRight, Sparkles, Loader2, Save, Link as LinkIcon, AlertCircle } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import GlassCard from './GlassCard';
import { analyzeVideoForHook } from '../services/geminiService';
import { api } from '../services/api';
import { AnalysisStatus, Hook } from '../types';

const Analyzer: React.FC = () => {
  const [url, setUrl] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<AnalysisStatus>(AnalysisStatus.IDLE);
  const [result, setResult] = useState<Hook | null>(null);
  const [error, setError] = useState('');
  const queryClient = useQueryClient();

  const saveMutation = useMutation({
    mutationFn: api.hooks.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hooks'] });
      setUrl('');
      setDescription('');
      setResult(null);
      setStatus(AnalysisStatus.IDLE);
      alert("Hook saved to Library!");
    },
  });

  const handleAnalyze = async () => {
    if (!url) return;
    setStatus(AnalysisStatus.ANALYZING);
    setError('');
    setResult(null);

    try {
      const analysis = await analyzeVideoForHook(url, description);
      
      const newHook: Hook = {
        id: crypto.randomUUID(),
        originalUrl: url,
        title: analysis.title,
        hookText: analysis.hookText,
        analysis: analysis.analysis,
        category: analysis.category,
        createdAt: Date.now()
      };
      
      setResult(newHook);
      setStatus(AnalysisStatus.SUCCESS);
    } catch (err) {
      setError('Failed to analyze video. Please check the URL or try again.');
      setStatus(AnalysisStatus.ERROR);
    }
  };

  const handleSave = () => {
    if (result) {
      saveMutation.mutate({
        title: result.title,
        hookText: result.hookText,
        analysis: result.analysis,
        category: result.category,
        videoUrl: result.originalUrl,
      });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center space-y-2">
        <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400">
          Video DNA Analyzer
        </h2>
        <p className="text-gray-400">
          Reverse-engineer viral success using the Callaway Filter.
        </p>
      </div>

      <GlassCard className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-300 uppercase tracking-wider">Video URL</label>
          <div className="relative">
            <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-5 h-5" />
            <input 
              type="text" 
              placeholder="https://youtube.com/shorts/..." 
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-xl glass-input placeholder-gray-600 focus:ring-2 focus:ring-purple-500 transition-all"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-300 uppercase tracking-wider">Context / Transcript (Optional)</label>
          <textarea 
            placeholder="Paste the transcript or a brief description of what happens in the video to help the AI extract the hook accurately..." 
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-4 h-32 rounded-xl glass-input placeholder-gray-600 focus:ring-2 focus:ring-purple-500 transition-all resize-none"
          />
        </div>

        <button 
          onClick={handleAnalyze}
          disabled={status === AnalysisStatus.ANALYZING || !url}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 font-bold text-lg hover:from-indigo-500 hover:to-purple-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20"
        >
          {status === AnalysisStatus.ANALYZING ? (
            <>
              <Loader2 className="animate-spin w-5 h-5" /> Decoding Viral DNA...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" /> Analyze Hook
            </>
          )}
        </button>

        {error && (
          <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/30 text-red-200 flex items-center gap-2">
            <AlertCircle className="w-5 h-5" /> {error}
          </div>
        )}
      </GlassCard>

      {result && (
        <GlassCard className="border-t-4 border-t-green-400 animate-in zoom-in-95 duration-500">
          <div className="flex justify-between items-start mb-6">
            <div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                {result.category}
              </span>
              <h3 className="text-2xl font-bold mt-2 text-white">{result.title}</h3>
            </div>
            <button 
              onClick={handleSave}
              className="px-6 py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 font-semibold transition-all flex items-center gap-2"
            >
              <Save className="w-4 h-4" /> Save to Library
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-gray-400 uppercase">The Hook (0-5s)</h4>
              <div className="p-4 rounded-xl bg-black/30 border border-white/5 text-lg italic text-purple-100 font-serif">
                "{result.hookText}"
              </div>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-gray-400 uppercase">Why It Works (Callaway Filter)</h4>
              <p className="text-gray-300 leading-relaxed">
                {result.analysis}
              </p>
            </div>
          </div>
        </GlassCard>
      )}
    </div>
  );
};

export default Analyzer;