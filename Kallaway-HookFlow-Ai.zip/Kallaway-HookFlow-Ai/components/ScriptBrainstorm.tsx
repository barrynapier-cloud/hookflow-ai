import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, Loader2, Trash2, Sparkles, Brain, User, RefreshCw, FolderOpen, ChevronDown } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import GlassCard from './GlassCard';
import { api, Framework } from '../services/api';
import { brainstormScript } from '../services/geminiService';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const ScriptBrainstorm: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedFramework, setSelectedFramework] = useState<Framework | null>(null);
  const [showFrameworkDropdown, setShowFrameworkDropdown] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const { data: frameworks = [] } = useQuery({
    queryKey: ['frameworks'],
    queryFn: api.frameworks.list,
  });

  const { data: allTrainingItems = [] } = useQuery({
    queryKey: ['all-training'],
    queryFn: api.training.list,
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      let trainingContext = '';
      
      if (allTrainingItems.length > 0) {
        const frameworkMap = new Map(frameworks.map(f => [f.id, f.name]));
        const groupedByFramework: Record<string, typeof allTrainingItems> = {};
        
        for (const item of allTrainingItems) {
          const frameworkName = item.frameworkId ? (frameworkMap.get(item.frameworkId) || 'General') : 'General';
          if (!groupedByFramework[frameworkName]) {
            groupedByFramework[frameworkName] = [];
          }
          groupedByFramework[frameworkName].push(item);
        }
        
        trainingContext = Object.entries(groupedByFramework)
          .map(([frameworkName, items]) => {
            const itemsContent = items.map(t => `### ${t.title}\n${t.content}`).join('\n\n');
            return `## ${frameworkName.toUpperCase()} FRAMEWORK\n\n${itemsContent}`;
          })
          .join('\n\n---\n\n');
      }

      const conversationHistory = messages.map(m => ({
        role: m.role,
        content: m.content
      }));

      const response = await brainstormScript(
        userMessage.content,
        conversationHistory,
        trainingContext,
        selectedFramework?.name
      );

      const assistantMessage: Message = {
        id: Math.random().toString(36).substr(2, 9),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: Math.random().toString(36).substr(2, 9),
        role: 'assistant',
        content: "Sorry, I encountered an error. Please try again.",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  const starterPrompts = [
    "Help me brainstorm hook ideas for a video about productivity tips",
    "I want to write a script about building wealth in your 20s",
    "Give me 5 viral video concepts for a fitness channel",
    "Help me develop a story-driven script about overcoming failure",
  ];

  return (
    <div className="w-full max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-400">
            Script Brainstorm
          </h2>
          <p className="text-gray-400 mt-2">
            Chat freely to develop ideas, outlines, and scripts
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setShowFrameworkDropdown(!showFrameworkDropdown)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-sm transition-all"
            >
              <FolderOpen className="w-4 h-4 text-cyan-400" />
              {selectedFramework ? selectedFramework.name : 'No framework'}
              <ChevronDown className={`w-4 h-4 transition-transform ${showFrameworkDropdown ? 'rotate-180' : ''}`} />
            </button>

            {showFrameworkDropdown && (
              <div className="absolute right-0 mt-2 w-48 rounded-lg bg-slate-800 border border-white/10 shadow-xl z-20 overflow-hidden">
                <button
                  onClick={() => {
                    setSelectedFramework(null);
                    setShowFrameworkDropdown(false);
                  }}
                  className={`w-full px-4 py-2 text-left text-sm hover:bg-white/10 transition-all ${
                    !selectedFramework ? 'bg-cyan-500/20 text-cyan-300' : 'text-gray-300'
                  }`}
                >
                  No framework
                </button>
                {frameworks.map(framework => (
                  <button
                    key={framework.id}
                    onClick={() => {
                      setSelectedFramework(framework);
                      setShowFrameworkDropdown(false);
                    }}
                    className={`w-full px-4 py-2 text-left text-sm hover:bg-white/10 transition-all ${
                      selectedFramework?.id === framework.id ? 'bg-cyan-500/20 text-cyan-300' : 'text-gray-300'
                    }`}
                  >
                    {framework.name}
                  </button>
                ))}
              </div>
            )}
          </div>

          {messages.length > 0 && (
            <button
              onClick={clearChat}
              className="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-red-500/20 text-gray-400 hover:text-red-400 border border-white/10 text-sm transition-all"
            >
              <Trash2 className="w-4 h-4" /> Clear
            </button>
          )}
        </div>
      </div>

      <GlassCard className="h-[600px] flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center px-4">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center mb-6 shadow-lg shadow-cyan-500/30">
                <MessageCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Start Brainstorming</h3>
              <p className="text-gray-400 mb-6 max-w-md">
                Have a free-form conversation to develop your script ideas. I'll help you explore concepts, build outlines, and refine your hooks.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-lg">
                {starterPrompts.map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => setInput(prompt)}
                    className="p-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-left text-sm text-gray-300 hover:text-white transition-all"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {message.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                      <Brain className="w-4 h-4 text-white" />
                    </div>
                  )}
                  
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      message.role === 'user'
                        ? 'bg-purple-600 text-white rounded-br-md'
                        : 'bg-white/10 text-gray-100 rounded-bl-md'
                    }`}
                  >
                    <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>
                  </div>
                  
                  {message.role === 'user' && (
                    <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
                      <User className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
              ))}
              
              {isLoading && (
                <div className="flex gap-3 justify-start">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                    <Brain className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-white/10 rounded-2xl rounded-bl-md px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                      <span className="text-sm text-gray-400">Thinking...</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        <div className="border-t border-white/10 p-4">
          <div className="flex gap-3">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message... (Enter to send, Shift+Enter for new line)"
              className="flex-1 p-3 rounded-xl glass-input resize-none text-sm"
              rows={2}
              disabled={isLoading}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="px-6 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 font-bold disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </div>
          
          {allTrainingItems.length > 0 && (
            <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              Powered by {allTrainingItems.length} training items across {frameworks.length} frameworks
              {selectedFramework && ` (focusing on ${selectedFramework.name})`}
            </p>
          )}
        </div>
      </GlassCard>
    </div>
  );
};

export default ScriptBrainstorm;
