import React, { useState } from 'react';
import { Trash2, Search, Loader2 } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import GlassCard from './GlassCard';
import { api, SavedHook } from '../services/api';

interface HookLibraryProps {
  onSelectHook?: (hook: SavedHook) => void;
  selectionMode?: boolean;
}

const HookLibrary: React.FC<HookLibraryProps> = ({ onSelectHook, selectionMode = false }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const queryClient = useQueryClient();

  const { data: hooks = [], isLoading } = useQuery({
    queryKey: ['hooks'],
    queryFn: api.hooks.list,
  });

  const deleteMutation = useMutation({
    mutationFn: api.hooks.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hooks'] });
    },
  });

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Delete this hook?')) {
      deleteMutation.mutate(id);
    }
  };

  const filteredHooks = hooks.filter(h => 
    h.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    h.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6 animate-in fade-in duration-700">
       <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
           <h2 className="text-3xl font-bold text-white">Hook Library</h2>
           <p className="text-gray-400 text-sm">Your database of proven viral patterns.</p>
        </div>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search hooks..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-full glass-input text-sm"
          />
        </div>
      </div>

      {hooks.length === 0 ? (
        <div className="text-center py-20 text-gray-500">
          <p>No hooks saved yet. Go to "Analyze" to add some!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredHooks.map((hook) => (
            <GlassCard 
              key={hook.id} 
              hoverEffect={true}
              onClick={() => selectionMode && onSelectHook && onSelectHook(hook)}
              className={selectionMode ? 'border-2 border-transparent hover:border-purple-500' : ''}
            >
              <div className="flex justify-between items-start mb-3">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 uppercase tracking-wide">
                  {hook.category}
                </span>
                {!selectionMode && (
                  <button 
                    onClick={(e) => handleDelete(e, hook.id)}
                    className="text-gray-500 hover:text-red-400 transition-colors"
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
              
              <h3 className="font-bold text-lg mb-2 text-white leading-tight">{hook.title}</h3>
              
              <div className="bg-black/40 rounded-lg p-3 mb-3 border border-white/5">
                 <p className="text-purple-200 italic font-serif text-sm line-clamp-3">"{hook.hookText}"</p>
              </div>

              <p className="text-xs text-gray-400 line-clamp-3">
                {hook.analysis}
              </p>
              
              {selectionMode && (
                <div className="mt-4 text-center text-sm font-semibold text-purple-400">
                  Click to Use
                </div>
              )}
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
};

export default HookLibrary;
