export interface SavedHook {
  id: string;
  userId: string;
  title: string;
  hookText: string;
  analysis: string;
  category: string;
  videoUrl?: string | null;
  createdAt?: string | null;
}

export interface Framework {
  id: string;
  userId: string;
  name: string;
  description?: string | null;
  createdAt?: string | null;
}

export interface TrainingItem {
  id: string;
  userId: string;
  frameworkId?: string | null;
  title: string;
  content: string;
  createdAt?: string | null;
}

async function fetchWithAuth(url: string, options: RequestInit = {}) {
  const response = await fetch(url, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  
  if (response.status === 401) {
    window.location.href = '/api/auth/google';
    throw new Error('Unauthorized');
  }
  
  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }
  
  return response.json();
}

export const api = {
  hooks: {
    list: (): Promise<SavedHook[]> => fetchWithAuth('/api/hooks'),
    create: (hook: Omit<SavedHook, 'id' | 'userId' | 'createdAt'>): Promise<SavedHook> =>
      fetchWithAuth('/api/hooks', { method: 'POST', body: JSON.stringify(hook) }),
    delete: (id: string): Promise<void> =>
      fetchWithAuth(`/api/hooks/${id}`, { method: 'DELETE' }),
  },
  frameworks: {
    list: (): Promise<Framework[]> => fetchWithAuth('/api/frameworks'),
    create: (framework: Omit<Framework, 'id' | 'userId' | 'createdAt'>): Promise<Framework> =>
      fetchWithAuth('/api/frameworks', { method: 'POST', body: JSON.stringify(framework) }),
    update: (id: string, data: Partial<Omit<Framework, 'id' | 'userId' | 'createdAt'>>): Promise<Framework> =>
      fetchWithAuth(`/api/frameworks/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: string): Promise<void> =>
      fetchWithAuth(`/api/frameworks/${id}`, { method: 'DELETE' }),
  },
  training: {
    list: (): Promise<TrainingItem[]> => fetchWithAuth('/api/training'),
    listByFramework: (frameworkId: string): Promise<TrainingItem[]> => 
      fetchWithAuth(`/api/training/framework/${frameworkId}`),
    create: (item: Omit<TrainingItem, 'id' | 'userId' | 'createdAt'>): Promise<TrainingItem> =>
      fetchWithAuth('/api/training', { method: 'POST', body: JSON.stringify(item) }),
    delete: (id: string): Promise<void> =>
      fetchWithAuth(`/api/training/${id}`, { method: 'DELETE' }),
  },
};
