import { GoogleGenAI, Type } from "@google/genai";
import Anthropic from "@anthropic-ai/sdk";
import { Hook, ResearchConfig, ViralIdea } from '../types';

// Initialize Gemini Client lazily to prevent crash on page load
let ai: GoogleGenAI | null = null;
let claudeClient: Anthropic | null = null;

const getAI = (): GoogleGenAI => {
  if (!ai) {
    const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("Please set the GEMINI_API_KEY environment variable to use AI features.");
    }
    ai = new GoogleGenAI({ apiKey });
  }
  return ai;
};

const getClaude = (): Anthropic => {
  if (!claudeClient) {
    const apiKey = process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY;
    const baseURL = process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL;
    if (!apiKey) {
      throw new Error("Claude API key not configured.");
    }
    claudeClient = new Anthropic({
      apiKey,
      baseURL,
      dangerouslyAllowBrowser: true
    });
  }
  return claudeClient;
};

// Helper to call Claude for research
const callClaude = async (prompt: string): Promise<string> => {
  const claude = getClaude();
  const message = await claude.messages.create({
    model: "claude-3-5-sonnet-20241022",
    max_tokens: 2048,
    messages: [{ role: "user", content: prompt }]
  });
  const content = message.content[0];
  return content.type === "text" ? content.text : "";
};

/**
 * Helper to inject training data - can fetch all or by framework
 */
const getTrainingContext = async (frameworkId?: string) => {
  try {
    const url = frameworkId 
      ? `/api/training/framework/${frameworkId}` 
      : '/api/training';
    const response = await fetch(url, { credentials: 'include' });
    if (!response.ok) return '';
    const knowledge = await response.json();
    return knowledge.length > 0 
      ? `\n\nCRITICAL: You must strictly adhere to the following Frameworks provided by the user:\n${knowledge.map((k: any) => `### ${k.title}\n${k.content}`).join('\n\n')}`
      : '';
  } catch {
    return '';
  }
};

// Exported version for components
export const getTrainingContextForFramework = getTrainingContext;

/**
 * Analyzes a video (via URL/Description) using the Callaway filter methodology.
 */
export const analyzeVideoForHook = async (
  url: string,
  description: string
): Promise<{ title: string; hookText: string; analysis: string; category: string }> => {
  
  const trainingContext = await getTrainingContext();

  const prompt = `
    You are an expert viral video consultant specializing in the "Callaway" method of video analysis.
    ${trainingContext}
    
    I will provide a Video URL and a description/transcript.
    Your goal is to reverse-engineer why this video was successful, specifically isolating the "Hook" (the first 3-5 seconds).
    
    Video URL: ${url}
    Context/Description: ${description}
    
    Please analyze this using the Callaway Filter (Attention, Interest, Desire, Action) but focus heavily on the ATTENTION mechanism (The Hook).
    
    Return the result in JSON format with the following keys:
    - title: A short catchy title for this hook pattern.
    - hookText: The extracted or reconstructed script of the hook itself.
    - analysis: A detailed paragraph explaining *why* it works psychologically.
    - category: One word category (e.g., Educational, Storytelling, Shock, Question, Visual).
  `;

  try {
    const response = await getAI().models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            hookText: { type: Type.STRING },
            analysis: { type: Type.STRING },
            category: { type: Type.STRING },
          },
          required: ["title", "hookText", "analysis", "category"]
        },
        tools: [{ googleSearch: {} }]
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};

/**
 * Extracts educational frameworks from a training video URL.
 */
export const analyzeTrainingVideo = async (
  url: string
): Promise<{ title: string; content: string }> => {
  const prompt = `
    I have a training video URL: ${url}
    
    My goal is to learn frameworks from this video to train an AI assistant that helps with viral content creation.
    The frameworks could be about: script writing, hook psychology, storytelling structure, video analysis, content strategy, or any other relevant methodology.
    
    Please access this video using your tools. 
    1. Identify the core methodology, steps, or rules taught.
    2. Extract them into a clean, structured text format suitable for system instructions.
    3. Create a concise title for this framework.
    
    Return the response as JSON:
    {
      "title": "The Framework Name",
      "content": "Step 1: ... \nStep 2: ... \n..."
    }
  `;

  try {
    const response = await getAI().models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.STRING },
          },
          required: ["title", "content"]
        },
        tools: [{ googleSearch: {} }]
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Training extraction failed:", error);
    throw error;
  }
};

/**
 * STEP 1: Generates 10 Viral Ideas based on Deep Research.
 */
export const generateViralIdeas = async (
  topic: string,
  config: ResearchConfig,
  onProgress: (status: string) => void,
  frameworkId?: string
): Promise<{ ideas: ViralIdea[]; researchSummary: string }> => {

  // 1. Parallel Research Phase
  onProgress("Deploying Research Agents (Gemini, Claude, Perplexity)...");
  
  const researchTasks: Promise<string>[] = [];
  
  if (config.useGemini) {
    researchTasks.push((async () => {
      try {
        const res = await getAI().models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `Role: Google Gemini. Task: Deep dive research on "${topic}". Verify all facts against trusted sources. Find the most surprising, counter-intuitive data points.`,
          config: { tools: [{ googleSearch: {} }] }
        });
        return `[GEMINI SOURCE]:\n${res.text}\n\n`;
      } catch (e) {
        console.error("Gemini research failed:", e);
        return ``;
      }
    })());
  }
  
  if (config.useClaude) {
    researchTasks.push((async () => {
      try {
        const result = await callClaude(`Analyze the psychological angles of "${topic}". How does this affect status, fear, or identity? Find the emotional core. Be thorough and provide specific insights.`);
        return `[CLAUDE SOURCE]:\n${result}\n\n`;
      } catch (e) {
        console.error("Claude research failed:", e);
        return ``;
      }
    })());
  }
  
  if (config.usePerplexity) {
    researchTasks.push((async () => {
      try {
        const res = await getAI().models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `Role: Research Assistant. Task: Find specific case studies, recent news, and obscure statistics about "${topic}" that nobody is talking about.`,
          config: { tools: [{ googleSearch: {} }] }
        });
        return `[PERPLEXITY SOURCE]:\n${res.text}\n\n`;
      } catch (e) {
        console.error("Perplexity research failed:", e);
        return ``;
      }
    })());
  }

  const researchResults = await Promise.all(researchTasks);
  const combinedResearch = researchResults.join("---\n");

  // 2. Synthesis Phase (Thinking Model)
  onProgress("Synthesizing 10 Winning Angles...");
  const trainingContext = await getTrainingContext(frameworkId);

  const ideationPrompt = `
    You are a Viral Content Strategist.
    ${trainingContext}

    TASK:
    Review the research below and generate a list of **10 Unique Viral Ideas** on the topic: "${topic}".
    
    CRITERIA:
    1. **Fact-Checked:** Ensure every claim is supported by the research provided.
    2. **Varied Angles:** Do not repeat the same concept. Use different frameworks (Contrarian, Data-Backed, Storytelling, Warning, Opportunity).
    3. **Strong Hooks:** Each idea must have a specific visual/audio hook concept.
    
    RESEARCH DATA:
    ${combinedResearch}
    
    OUTPUT JSON:
    {
      "ideas": [
        {
          "angle": "The specific angle (e.g., The Hidden Danger)",
          "headline": "A 1-sentence viral headline",
          "hookConcept": "Describe the visual/audio opening (0-3s)",
          "whyItWorks": "Psychological reasoning",
          "researchFact": "The specific fact/stat backing this"
        }
      ]
    }
  `;

  try {
    const response = await getAI().models.generateContent({
      model: 'gemini-3-pro-preview', 
      contents: ideationPrompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: {
            thinkingBudget: config.thinkingBudget > 0 ? config.thinkingBudget : 2048
        },
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                ideas: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            angle: {type: Type.STRING},
                            headline: {type: Type.STRING},
                            hookConcept: {type: Type.STRING},
                            whyItWorks: {type: Type.STRING},
                            researchFact: {type: Type.STRING}
                        }
                    }
                }
            }
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      ideas: result.ideas.map((i: any) => ({ ...i, id: crypto.randomUUID() })),
      researchSummary: combinedResearch
    };
  } catch (error) {
    console.error("Ideation failed:", error);
    throw error;
  }
};

/**
 * STEP 2: Remixes a specific idea based on chat instructions.
 */
export const remixViralIdea = async (
  currentIdea: ViralIdea,
  instruction: string,
  researchContext: string,
  frameworkId?: string
): Promise<ViralIdea> => {
    const trainingContext = await getTrainingContext(frameworkId);

    const prompt = `
        You are a "Hook Doctor" and Content Editor.
        ${trainingContext}

        Current Idea:
        Headline: ${currentIdea.headline}
        Hook: ${currentIdea.hookConcept}
        Angle: ${currentIdea.angle}

        Research Context:
        ${researchContext.substring(0, 3000)}... (truncated)

        USER INSTRUCTION: "${instruction}"

        Task: Rewrite the headline, hook, and angle to satisfy the user's instruction.
        Keep the same underlying fact/research.
        
        Return JSON with the updated fields.
    `;

    const response = await getAI().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    angle: {type: Type.STRING},
                    headline: {type: Type.STRING},
                    hookConcept: {type: Type.STRING},
                    whyItWorks: {type: Type.STRING},
                    researchFact: {type: Type.STRING}
                }
            }
        }
    });

    const text = response.text;
    if(!text) throw new Error("Failed to remix");
    const result = JSON.parse(text);
    return { ...currentIdea, ...result };
};

/**
 * STEP 3: Writes the final script.
 */
export const writeFinalScript = async (
  idea: ViralIdea,
  selectedHookPattern: Hook | null,
  researchNotes: string,
  frameworkId?: string
): Promise<string> => {

  const trainingContext = await getTrainingContext(frameworkId);

  const writingPrompt = `
    You are a master scriptwriter.
    ${trainingContext}
    
    STEP 1: Review the Research Notes and the Selected Idea.
    STEP 2: Write a compelling video script (approx 60-90 seconds spoken).
    
    THE IDEA:
    Headline: ${idea.headline}
    Angle: ${idea.angle}
    Hook Concept: ${idea.hookConcept}
    Core Fact: ${idea.researchFact}
    
    ${selectedHookPattern ? `MANDATORY STRUCTURAL TEMPLATE: Use the structure of this saved hook: "${selectedHookPattern.hookText}"` : ''}
    
    RESEARCH NOTES:
    ${researchNotes}
    
    Output Format:
    Return JSON with { "scriptContent": "..." }
  `;

  try {
    const response = await getAI().models.generateContent({
      model: 'gemini-3-pro-preview', 
      contents: writingPrompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingBudget: 2048 } 
      }
    });

    const result = JSON.parse(response.text || "{}");
    return result.scriptContent || "Failed to generate script content.";
  } catch (error) {
    console.error("Script generation failed:", error);
    throw error;
  }
};

/**
 * Rewrites and improves an existing script.
 */
export const rewriteScript = async (
  originalScript: string,
  instructions: string,
  onProgress: (msg: string) => void,
  frameworkId?: string
): Promise<string> => {
  onProgress("Loading training context...");
  const trainingContext = await getTrainingContext(frameworkId);

  onProgress("Analyzing script structure...");
  
  const rewritePrompt = `
    You are an expert viral content scriptwriter and editor.
    ${trainingContext}

    Your task is to rewrite and dramatically improve the following script based on the user's instructions.

    ORIGINAL SCRIPT:
    """
    ${originalScript}
    """

    USER INSTRUCTIONS:
    ${instructions}

    REWRITING GUIDELINES:
    1. HOOK: Ensure the opening 3 seconds are absolutely captivating - use pattern interrupts, curiosity gaps, or bold statements
    2. STRUCTURE: Apply proven viral content structures (problem-agitate-solve, story-lesson, myth-truth, etc.)
    3. PACING: Vary sentence length, use short punchy lines for impact, longer ones for explanation
    4. EMOTIONAL TRIGGERS: Weave in curiosity, fear of missing out, desire, or controversy where appropriate
    5. SPECIFICITY: Replace vague statements with specific numbers, examples, or stories
    6. CALL TO ACTION: Ensure there's a clear, compelling reason to watch till the end or take action
    7. VOICE: Keep the authentic voice while making it more engaging

    Output Format:
    Return JSON with { "rewrittenScript": "..." }
    
    The rewritten script should be ready to read/perform - no stage directions or notes, just the actual script text.
  `;

  try {
    onProgress("Rewriting with AI...");
    
    const response = await getAI().models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: rewritePrompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingBudget: 4096 }
      }
    });

    onProgress("Polishing final output...");
    const result = JSON.parse(response.text || "{}");
    return result.rewrittenScript || "Failed to rewrite script.";
  } catch (error) {
    console.error("Script rewrite failed:", error);
    throw error;
  }
};

/**
 * Interactive brainstorming chat for script development.
 */
export const brainstormScript = async (
  userMessage: string,
  conversationHistory: Array<{ role: string; content: string }>,
  trainingContext: string = '',
  frameworkName?: string
): Promise<string> => {
  const systemPrompt = `
    You are an expert viral content strategist and script brainstorming partner. You help creators develop ideas, hooks, outlines, and full scripts through interactive conversation.
    ${trainingContext ? `\n\nIMPORTANT: Apply the following training frameworks in your responses:\n${trainingContext}` : ''}
    ${frameworkName ? `\nYou are currently using the "${frameworkName}" framework style.` : ''}

    YOUR ROLE:
    - Be a creative collaborator, not just an assistant
    - Ask clarifying questions when needed to give better advice
    - Offer multiple options and variations when brainstorming
    - Challenge weak ideas constructively and suggest improvements
    - Provide specific, actionable feedback - not generic advice
    - When asked for hooks, give complete, ready-to-use examples
    - When developing scripts, think about pacing, emotional beats, and retention

    BRAINSTORMING APPROACH:
    1. For IDEAS: Generate unexpected angles, contrarian takes, and curiosity-inducing concepts
    2. For HOOKS: Focus on pattern interrupts, bold claims, mystery, or immediate value
    3. For STRUCTURE: Apply proven viral frameworks (problem-solution, story-lesson, myth vs truth)
    4. For SCRIPTS: Consider the 3-second hook, emotional journey, and satisfying payoff

    Keep responses conversational but packed with value. Use bullet points for lists, but write scripts as flowing prose.
  `;

  const messages = [
    ...conversationHistory.map(m => ({
      role: m.role as 'user' | 'assistant',
      content: m.content
    })),
    { role: 'user' as const, content: userMessage }
  ];

  try {
    const claude = getClaude();
    const response = await claude.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 2048,
      system: systemPrompt,
      messages: messages
    });

    const content = response.content[0];
    return content.type === "text" ? content.text : "I couldn't generate a response.";
  } catch (error: any) {
    console.error("Brainstorm failed:", error?.message || error);
    throw error;
  }
};

/**
 * Generates scroll-stopping titles and captions for social media.
 */
export const generateCaptions = async (
  topic: string,
  platform: 'youtube' | 'tiktok' | 'instagram' | 'twitter',
  tone: 'bold' | 'curiosity' | 'controversial' | 'educational' | 'emotional',
  trainingContext: string = ''
): Promise<Array<{ title: string; caption: string; hashtags: string[]; cta: string; complianceNotes: string[] }>> => {
  const platformGuidelines = {
    youtube: 'YouTube titles should be 60 chars max, use caps strategically, include numbers/power words',
    tiktok: 'TikTok captions are short and punchy, use trending sounds references, keep under 150 chars for display',
    instagram: 'Instagram allows longer captions, start with hook, use line breaks, 2200 char limit',
    twitter: 'X/Twitter needs to be under 280 chars, be provocative, encourage engagement'
  };

  const complianceGuidelines = {
    youtube: `
      YOUTUBE COMPLIANCE:
      - No misleading thumbnails/titles (clickbait that doesn't deliver)
      - No excessive caps (max 30% of title)
      - Avoid sensationalized claims without evidence
      - No spam hashtags in description
      - Disclose paid promotions/sponsorships
      - Age-appropriate content labeling
    `,
    tiktok: `
      TIKTOK COMPLIANCE (CRITICAL):
      - NO income claims or "get rich quick" language
      - NO guaranteed results promises ("you WILL make $X")
      - Avoid financial advice without disclaimers
      - NO fake urgency ("last chance", "ending soon" if not true)
      - NO misleading before/after claims
      - Avoid words: "free money", "passive income guarantee", "secret method"
      - Disclose paid partnerships with #ad or #sponsored
      - No content promoting dangerous activities
      - Avoid spam hashtags (max 3-5 relevant ones)
      - No engagement bait ("follow for part 2" without delivering)
      - Must comply with music/sound licensing
    `,
    instagram: `
      INSTAGRAM COMPLIANCE:
      - Disclose partnerships with "Paid partnership" tag or #ad
      - No fake engagement tactics
      - Avoid banned hashtags (check before posting)
      - No misleading health/fitness claims
      - Respect copyright on images/music
      - No spam or repetitive hashtags
    `,
    twitter: `
      X/TWITTER COMPLIANCE:
      - No misleading content or fake news
      - Disclose promotions with #ad
      - No spam or excessive hashtags
      - Avoid coordinated inauthentic behavior
      - No manipulation or platform abuse
    `
  };

  const toneGuidelines = {
    bold: 'Use direct, confident statements. Make bold claims. Be authoritative.',
    curiosity: 'Create information gaps. Use "what if", "how", "why most people fail". Tease without revealing.',
    controversial: 'Challenge common beliefs. Use "unpopular opinion", "hot take". Be polarizing but not offensive.',
    educational: 'Promise specific knowledge. Use "how to", "X ways to", "the truth about". Be value-focused.',
    emotional: 'Tap into feelings. Use storytelling hooks, relatable struggles, aspirational outcomes.'
  };

  const prompt = `
    You are an expert social media copywriter specializing in viral content.
    ${trainingContext ? `\n\nAPPLY THESE FRAMEWORKS:\n${trainingContext}` : ''}

    Create 3 scroll-stopping title and caption combinations for this content:
    
    TOPIC/CONTENT: ${topic}
    PLATFORM: ${platform.toUpperCase()}
    TONE: ${tone}
    
    PLATFORM GUIDELINES: ${platformGuidelines[platform]}
    TONE GUIDELINES: ${toneGuidelines[tone]}
    
    ${complianceGuidelines[platform]}
    
    CRITICAL: You MUST ensure all content is compliant with the platform's policies listed above.
    For TikTok especially, avoid ANY language that could trigger shadowbans or content removal.
    
    SCROLL-STOPPING TECHNIQUES (use while staying compliant):
    1. Pattern interrupt - say something unexpected
    2. Specificity - use exact numbers and details (but no income guarantees)
    3. Curiosity gap - hint at value without revealing
    4. Bold claims - make statements that demand attention (but can be backed up)
    5. Relatability - speak to specific pain points
    6. Controversy - challenge conventional wisdom (without violating guidelines)
    7. Urgency - create FOMO or time sensitivity (if genuine)
    
    For each variation, provide:
    - title: The main title/headline (platform-optimized length)
    - caption: The post caption/description
    - hashtags: ${platform === 'tiktok' ? '3-5' : '5-8'} relevant hashtags (include mix of popular and niche)
    - cta: A compelling call-to-action for engagement
    - complianceNotes: Array of 1-3 brief notes about compliance considerations for this specific caption (e.g., "Uses curiosity without making income promises", "May need #ad if sponsored")
    
    Return JSON: { "captions": [{ "title": "", "caption": "", "hashtags": ["#tag1"], "cta": "", "complianceNotes": ["note1"] }] }
    
    Make each variation distinctly different in approach while ALL staying platform-compliant.
  `;

  try {
    const response = await getAI().models.generateContent({
      model: 'gemini-2.0-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text || "{}");
    return result.captions || [];
  } catch (error) {
    console.error("Caption generation failed:", error);
    throw error;
  }
};