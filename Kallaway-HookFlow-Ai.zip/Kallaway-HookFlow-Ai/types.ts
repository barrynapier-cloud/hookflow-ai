export interface Hook {
  id: string;
  originalUrl: string;
  title: string;
  hookText: string;
  analysis: string; // The "Callaway" analysis breakdown
  category: string;
  createdAt: number;
}

export interface Script {
  id: string;
  topic: string;
  hookId: string;
  content: string;
  researchNotes: string;
  usedModels: string[];
  createdAt: number;
}

export interface ViralIdea {
  id: string;
  angle: string; // The core concept
  headline: string; // Catchy title
  hookConcept: string; // The visual/audio hook idea
  whyItWorks: string; // Brief validation
  researchFact: string; // The core fact backing this
}

export interface ResearchConfig {
  useGemini: boolean;
  useClaude: boolean; // Simulation
  usePerplexity: boolean; // Simulation
  thinkingBudget: number; // For Gemini Pro
}

export interface KnowledgeItem {
  id: string;
  title: string;
  content: string; // Transcripts, principles, frameworks, or rules
  createdAt: number;
}

export enum AnalysisStatus {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export enum GenerationStatus {
  IDLE = 'IDLE',
  RESEARCHING = 'RESEARCHING', // Generating Ideas
  IDEATION_COMPLETE = 'IDEATION_COMPLETE', // 10 Ideas ready
  REMIXING = 'REMIXING', // Refining an idea
  WRITING = 'WRITING', // Final script gen
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}