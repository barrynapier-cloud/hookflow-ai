import { sql } from "drizzle-orm";
import { pgTable, varchar, text, timestamp, jsonb, index } from "drizzle-orm/pg-core";

export * from "./models/auth";

export const savedHooks = pgTable("saved_hooks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: varchar("title").notNull(),
  hookText: text("hook_text").notNull(),
  analysis: text("analysis").notNull(),
  category: varchar("category").notNull(),
  videoUrl: varchar("video_url"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [index("idx_hooks_user").on(table.userId)]);

export const frameworks = pgTable("frameworks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: varchar("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [index("idx_frameworks_user").on(table.userId)]);

export const trainingItems = pgTable("training_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  frameworkId: varchar("framework_id"),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_training_user").on(table.userId),
  index("idx_training_framework").on(table.frameworkId),
]);

export type SavedHook = typeof savedHooks.$inferSelect;
export type InsertSavedHook = typeof savedHooks.$inferInsert;
export type Framework = typeof frameworks.$inferSelect;
export type InsertFramework = typeof frameworks.$inferInsert;
export type TrainingItem = typeof trainingItems.$inferSelect;
export type InsertTrainingItem = typeof trainingItems.$inferInsert;
