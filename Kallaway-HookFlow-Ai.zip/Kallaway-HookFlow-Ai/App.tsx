import React, { useState } from 'react';
import { LayoutDashboard, Library, PenTool, Sparkles, GraduationCap, LogOut, User, RefreshCw, MessageCircle, Type } from 'lucide-react';
import { useAuth } from './hooks/use-auth';
import Analyzer from './components/Analyzer';
import HookLibrary from './components/HookLibrary';
import ScriptWriter from './components/ScriptWriter';
import ScriptRewriter from './components/ScriptRewriter';
import ScriptBrainstorm from './components/ScriptBrainstorm';
import CaptionCreator from './components/CaptionCreator';
import KnowledgeBase from './components/KnowledgeBase';

const LandingPage: React.FC = () => (
  <div className="min-h-screen relative overflow-x-hidden text-white flex items-center justify-center">
    <div className="fixed inset-0 bg-[#0f172a] -z-20" />
    <div className="fixed top-[-20%] left-[-20%] w-[50%] h-[50%] bg-purple-900/30 rounded-full blur-[128px] -z-10 animate-pulse" />
    <div className="fixed bottom-[-20%] right-[-20%] w-[50%] h-[50%] bg-indigo-900/30 rounded-full blur-[128px] -z-10 animate-pulse delay-700" />
    
    <div className="text-center px-4">
      <div className="flex items-center justify-center gap-3 mb-6">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
          <Sparkles className="text-white w-10 h-10" />
        </div>
      </div>
      <h1 className="text-5xl font-bold tracking-tight mb-4">HookFlow AI</h1>
      <p className="text-xl text-gray-400 mb-8 max-w-lg mx-auto">
        Reverse-engineer viral success. Analyze hooks, train AI with your frameworks, and generate winning scripts.
      </p>
      <a 
        href="/api/auth/google"
        className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full text-lg font-semibold hover:from-purple-500 hover:to-indigo-500 transition-all shadow-lg shadow-purple-500/30"
      >
        Sign in with Google
      </a>
    </div>
  </div>
);

const App: React.FC = () => {
  const { user, isLoading, isAuthenticated, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'analyze' | 'write' | 'rewrite' | 'brainstorm' | 'captions' | 'training' | 'library'>('analyze');

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0f172a]">
        <div className="animate-spin w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LandingPage />;
  }

  return (
    <div className="min-h-screen relative overflow-x-hidden text-white selection:bg-purple-500 selection:text-white">
      <div className="fixed inset-0 bg-[#0f172a] -z-20" />
      <div className="fixed top-[-20%] left-[-20%] w-[50%] h-[50%] bg-purple-900/30 rounded-full blur-[128px] -z-10 animate-pulse" />
      <div className="fixed bottom-[-20%] right-[-20%] w-[50%] h-[50%] bg-indigo-900/30 rounded-full blur-[128px] -z-10 animate-pulse delay-700" />
      <div className="fixed top-[20%] right-[10%] w-[30%] h-[30%] bg-pink-900/20 rounded-full blur-[100px] -z-10" />

      <div className="container mx-auto px-4 py-8 flex flex-col min-h-screen">
        
        <header className="flex flex-col md:flex-row items-center justify-between mb-12 animate-in fade-in slide-in-from-top-4 duration-700">
          <div className="flex items-center gap-3 mb-6 md:mb-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">HookFlow AI</h1>
          </div>

          <div className="flex items-center gap-4">
            <nav className="p-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-md overflow-x-auto max-w-full">
              <ul className="flex items-center gap-1">
                <li>
                  <button 
                    onClick={() => setActiveTab('analyze')}
                    className={`px-3 md:px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === 'analyze' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  >
                    <LayoutDashboard className="w-4 h-4" /> Analyze
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveTab('write')}
                    className={`px-3 md:px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === 'write' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  >
                    <PenTool className="w-4 h-4" /> Create
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveTab('rewrite')}
                    className={`px-3 md:px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === 'rewrite' ? 'bg-orange-500/20 text-orange-300 shadow-sm border border-orange-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  >
                    <RefreshCw className="w-4 h-4" /> Rewrite
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveTab('brainstorm')}
                    className={`px-3 md:px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === 'brainstorm' ? 'bg-cyan-500/20 text-cyan-300 shadow-sm border border-cyan-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  >
                    <MessageCircle className="w-4 h-4" /> Brainstorm
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveTab('captions')}
                    className={`px-3 md:px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === 'captions' ? 'bg-yellow-500/20 text-yellow-300 shadow-sm border border-yellow-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  >
                    <Type className="w-4 h-4" /> Captions
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveTab('training')}
                    className={`px-3 md:px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === 'training' ? 'bg-emerald-500/20 text-emerald-300 shadow-sm border border-emerald-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  >
                    <GraduationCap className="w-4 h-4" /> Training
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveTab('library')}
                    className={`px-3 md:px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === 'library' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                  >
                    <Library className="w-4 h-4" /> Library
                  </button>
                </li>
              </ul>
            </nav>

            <div className="flex items-center gap-2">
              {user?.profileImageUrl ? (
                <img src={user.profileImageUrl} alt="" className="w-8 h-8 rounded-full" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
              )}
              <button
                onClick={() => logout()}
                className="p-2 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-all"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1">
          {activeTab === 'analyze' && <Analyzer />}
          {activeTab === 'write' && <ScriptWriter />}
          {activeTab === 'rewrite' && <ScriptRewriter />}
          {activeTab === 'brainstorm' && <ScriptBrainstorm />}
          {activeTab === 'captions' && <CaptionCreator />}
          {activeTab === 'training' && <KnowledgeBase />}
          {activeTab === 'library' && <HookLibrary />}
        </main>

        <footer className="mt-20 py-6 border-t border-white/5 text-center text-gray-600 text-sm">
          <p>Powered by Google Gemini Pro Thinking Models</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
